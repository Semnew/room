(function($){
    "use strict";
    let mouseAtX = 0;
    let hasTouchMove = false;
    if ("touchmove" in document.createElement("div")){
        hasTouchMove = true;
    }
    $(document).ready(function(){
        bindJumpToFeedback();
        bindBackToTop();

        if('undefined' === typeof (LocalConst.IS_MOBILE)){
            return false;
        }
        if(window.innerWidth < 888){
            setAutoHideMenus();
        }
        bindNavEvent();
        bindTOCEvent();
        $(window).bind("scroll", function(e){
            scalePage(e);
            doTOCScrollEvent();
        });
        $(window).bind("mousemove", function(e){
            mouseAtX = e.clientX;
        });
        $('.slide-toggle').click(function(e){
            $('.category-list').each(function(){
                $(this).toggleClass('hide');
            });
        });
        bindReadSettingEvent();
        bindThemeChangeEvent();
        bindSwitchFontFamily();
        bindFontSizeControl();
        $('.blog-notice>a.blog-notice-close').click(function (e) {
            $(this).parent().remove();
        });
        if (LocalConst.COMMENT_SYSTEM === LocalConst.COMMENT_SYSTEM_EMBED) {
            loadCommentEmoji();
        }
        bindAjaxComment();
    });
    window.onload = function () {
        hideSPProgress(200);
    };
    console.log("\n %c Mirages " + LocalConst.THEME_VERSION + " %c https://get233.com/archives/mirages-intro.html \n\n", "color: #fff; background-image: linear-gradient(90deg, rgb(47, 172, 178) 0%, rgb(45, 190, 96) 100%); padding:5px 1px;", "background-image: linear-gradient(90deg, rgb(45, 190, 96) 0%, rgb(255, 255, 255) 100%); padding:5px 0;");
    let scrollIndex = {};
    let scrollIndexKeys = [];
    let newCommentIndex = 1;
    let bindBackToTop = function () {
        // 返回顶部
        let backtop = $("span#backtop");
        let body = $("body");
        backtop.click(function(){
            $('html, body').animate(
                {scrollTop: 0},600
            );
        });
        // 显示返回顶部按钮
        if($(window).scrollTop() > 100){
            // backtop.addClass('show')
            body.addClass('show-back-to-top')
        }
        $(window).scroll(function(){
            if($(window).scrollTop() > 100){
                // backtop.addClass('show')
                body.addClass('show-back-to-top')
            }else{
                // backtop.removeClass('show')
                body.removeClass('show-back-to-top')
            }
        });
    };
    let scalePage = function (e) {
        let wrap = $("#wrap");
        let nav = wrap.find("#nav");
        if (nav.width() < mouseAtX) {
            if ((LocalConst.IS_MOBILE && hasTouchMove) || !LocalConst.IS_MOBILE){
                $('#wrap.display-nav').find('#body').unbind('click');
                wrap.removeClass('display-nav');
                $("body").removeClass('display-nav');
                let toolbar = $('#nav-toolbar').find('.side-toolbar');
                toolbar.removeClass("show-read-settings");
                $('#footer').removeClass('display-nav');
            }
        }
    };
    let onBodyHeightChange = function(timeInterval, callback){
        let body = document.body,
            html = document.documentElement;
        let getBodyHeight = function () {
            return Math.max(body.scrollHeight, body.offsetHeight,
                html.clientHeight, html.scrollHeight, html.offsetHeight);
        };
        let lastHeight = getBodyHeight(), newHeight;
        (function run() {
            newHeight = getBodyHeight();
            if(lastHeight !== newHeight) {
                callback();
            }
            lastHeight = newHeight;
            if(body.onElementHeightChangeTimer) {
                clearTimeout(body.onElementHeightChangeTimer);
            }
            body.onElementHeightChangeTimer = setTimeout(run, timeInterval);
        })();
    };
    let offBodyHeightChange = function () {
        if(document.body.onElementHeightChangeTimer) {
            clearTimeout(document.body.onElementHeightChangeTimer);
        }
    };
    let bindJumpToFeedback = function () {
        $('#feedback').click(function(){
            $('html, body').animate(
                {scrollTop: $("#comments").offset().top}
            );
        });
    };
    let setAutoHideMenus = function(){
        let nav = new Headroom(document.querySelector("#toggle-nav"), {
            tolerance: 5,
            offset : 5,
            classes: {
                initial: "show",
                pinned: "show",
                unpinned: "hide"
            }
        });
        nav.init();
    };
    let bindNavEvent = function () {
        $('#toggle-nav').off('click').on('click', function(e){
            let wrap = $("#wrap");
            let bd = $("body");
            wrap.removeClass("scale-up").toggleClass('display-nav');
            bd.toggleClass('display-nav');
            let toolbar = $('#nav-toolbar').find('.side-toolbar');
            toolbar.removeClass("show-read-settings");
            if (LocalConst.TOC_AT_LEFT) {
                wrap.toggleClass('hide-menu-tree');
            } else {
                wrap.removeClass('display-menu-tree');
                bd.removeClass('display-menu-tree');
            }
            $('#footer').toggleClass('display-nav');
            $('#toggle-nav').removeClass('hide');

            setTimeout(function () {
                let body = $('#body');
                body.off('click').on('click', function(e){
                    body.off('click');
                    wrap.removeClass('display-nav').removeClass('hide-menu-tree');
                    bd.removeClass('display-nav');
                    if (!LocalConst.TOC_AT_LEFT) {
                        $('#wrap').removeClass('display-menu-tree')
                        bd.removeClass('display-menu-tree')
                    }
                    toolbar.removeClass("show-read-settings");
                    $('#footer').removeClass('display-nav');
                    e.preventDefault();
                });
                body.off('touchmove').on('touchmove', function(e){
                    body.off('click');
                    wrap.removeClass('display-nav').removeClass('hide-menu-tree');
                    bd.removeClass('display-nav');
                    if (!LocalConst.TOC_AT_LEFT) {
                        $('#wrap').removeClass('display-menu-tree')
                        bd.removeClass('display-menu-tree')
                    }
                    toolbar.removeClass("show-read-settings");
                    $('#footer').removeClass('display-nav');
                });
            }, 500);

        });
    };
    let trim = function (str) {
        return $.trim(str);
    };
    let bindAjaxComment = function () {
        if (!LocalConst.ENABLE_PJAX) {
            return;
        }
        $('#comment-form').off('submit').on('submit', function (e) {
            let form = $(this);
            let submit = form.find('#submit');

            let respondDiv = form.parents('.respond');
            let respondParent = respondDiv.parent();

            let author = form.find('#author').val();
            let website = form.find('#url').val();
            let commentText = form.find('#textarea').val();

            if (commentText === null || trim(commentText) === '') {
                alert(submit.attr('data-empty-comment'));
                return false;
            }

            if (form.find('#author').length === 0 && form.find('#url').length === 0) {
                author = $('a[href$="profile.php"]').text();
                website = document.location.origin;
            }

            submit.attr('disabled', 'disabled').val(submit.attr('data-posting'));

            let newCommentId = 'newComment-' + newCommentIndex;
            newCommentIndex++;
            let newComment =
                '<li itemscope="" itemtype="http://schema.org/UserComments" id="' + newCommentId + '" class="comment-body">' +
                '<div class="comment-author" itemprop="creator" itemscope="" itemtype="http://schema.org/Person">' +
                '<span itemprop="image"><img class="avatar" src="https://secure.gravatar.com/avatar/8d0cad9fd3e982f30620bc96ec639cfb?s=100&amp;r=PG&amp;d=" alt="' + author + '" width="100" height="100"></span>' +
                '<cite class="fn color-main" itemprop="name"><a href="' + website + '" rel="external nofollow" target="_blank">' + author + '</a></cite>' +
                '</div>' +
                '<div class="comment-meta">' +
                '<a href="javascript:void(0)"><time itemprop="commentTime" datetime="' + submit.attr('data-now') + '">' + submit.attr('data-now') + '</time></a>' +
                '<span id="' + newCommentId + '-status" class="comment-posting">' + submit.attr('data-posting') + '</span>' +
                '</div>' +
                '<div class="comment-content" itemprop="commentText">' +
                '<p>' + renderSmiles(commentText) + '</p>' +
                '</div>' +
                '</li>';
            let added = false;
            let firstComment = false;
            let commentOrderDESC = LocalConst.COMMENTS_ORDER === 'DESC';
            if (respondParent.is('div') && respondParent.attr('id') === 'comments') {
                // 评论为新评论，加在主评论列表中

                // 评论列表存在
                if (respondParent.children('.comment-list').length > 0) {
                    if (commentOrderDESC) {
                        respondParent.children('.comment-list').first().prepend(newComment);
                    } else {
                        respondParent.children('.comment-list').first().append(newComment);
                    }
                } else {
                    // 文章的第一条评论
                    respondParent.append('<div class="comment-separator">'+
                                '<div class="comment-tab-current">'+
                                '<span class="comment-num">已有 1 条评论</span>' +
                                '</div>'+
                                '</div>');
                    respondParent.append('<ol class="comment-list">' + newComment + '</ol>');
                    firstComment = true;
                }
                added = true;
            } else if (respondParent.is('li') && respondParent.hasClass('comment-body')) {
                if (respondParent.parent().parent().is('div') && respondParent.parent().parent().attr('id') === 'comments') {
                    // 评论主评论，加在主评论的子列表中
                    if (respondParent.children('.comment-children').first().children('.comment-list').length > 0) {
                        respondParent.children('.comment-children').first().children('.comment-list').first().append(newComment);
                    } else {
                        var commentList = '<div class="comment-children" itemprop="discusses"><ol class="comment-list">'
                            + newComment + '</ol></div>';
                        respondParent.append(commentList);
                    }
                } else {
                    // 评论子评论，加在子评论列表最后
                    respondParent.parents('.comment-list').first().append(newComment);
                }
                added = true;
            }
            if (added) {
                try {
                    let offset = $('#' + newCommentId).offset();
                    if (typeof offset !== 'undefined') {
                        $('html, body').animate(
                            {scrollTop: offset.top - 50}, 300
                        );
                    }
                } catch (e) {
                    console.error(e);
                }
                let error = function () {
                    try {
                        if (firstComment) {
                            respondParent.children('.comment-separator').first().remove();
                            respondParent.children('.comment-list').first().remove();
                        } else {
                            $('#' + newCommentId).remove();
                        }
                        let offset = $('#comment-form').offset();
                        if (typeof offset !== 'undefined') {
                            $('html, body').animate(
                                {scrollTop: offset.top - 100}, 300
                            );
                        }
                    } catch (e) {
                        console.error(e);
                    }
                };
                try {
                    $.ajax({
                        url: form.attr('action'),
                        type: form.attr('method'),
                        data: form.serializeArray(),
                        success: function(data) {
                            if (typeof data === 'undefined') {
                                window.location.reload();
                                return false;
                            }
                            if (data.indexOf('<title>' + 'Error</title>') > 0) {
                                let el = $('<div></div>');
                                el.html(data);
                                alert(trim($('.container', el).text()));
                                error();
                            } else {
                                form.find('#textarea').val('');
                                if (typeof(TypechoComment) !== 'undefined') {
                                    TypechoComment.cancelReply();
                                }
                                let commentList = data.match(/id="comment-\d+"/g);
                                if (commentList === null || commentList.length === 0) {
                                    window.location.reload();
                                } else {
                                    let new_id = commentList.join().match(/\d+/g).sort(function(a, b) {
                                        return a - b
                                    }).pop();
                                    let el = $('<div></div>');
                                    el.html(data);
                                    let resultElement = $('#comment-' + new_id, el);
                                    if (trim(resultElement.children('.comment-author').find('cite.fn a').text()) === trim(author)) {
                                        resultElement.children('.comment-meta').append('<span id="comment-' + new_id + '-status" class="comment-posted">' + submit.attr('data-posted') + '</span>');
                                        let content = resultElement.children('.comment-content');
                                        content.html(renderSmiles(content.html()));
                                        $('#' + newCommentId).replaceWith(resultElement);
                                    } else {
                                        $('#' + newCommentId + "-status").text(submit.attr('data-posted')).removeClass('comment-posting').addClass('comment-posted');
                                    }
                                }
                            }
                            submit.removeAttr('disabled').val(submit.attr('data-init'));
                        },
                        error: function(e) {
                            console.error(e);
                            error();
                            submit.removeAttr('disabled').val(submit.attr('data-init'));
                            // return true;
                        }
                    });
                    return false;
                } catch (e) {
                    console.error(e);
                }
            }
            return false;
        });
    };
    let bindTOCEvent = function () {
        if (!LocalConst.SHOW_TOC) {
            return;
        }
        if (window.innerWidth < 888) {
            let menuTree = new Headroom(document.querySelector("#toggle-menu-tree"), {
                tolerance: 5,
                offset : 5,
                classes: {
                    initial: "show",
                    pinned: "show",
                    unpinned: "hide"
                }
            });
            menuTree.init();
        }

        offBodyHeightChange();
        onBodyHeightChange(700, function() {
            reCalcTOCIndex();
        });

        $("div.post-content>h1, div.post-content>h2, div.post-content>h3, div.post-content>h4, div.post-content>h5, div.post-content>h6").each(function () {
            $(this).append('<span class="toc">展开目录</span>');
            $(this).find('span.toc').click(function (e) {
                if ($(this).css('opacity') > 0) {
                    toggleMenuTree(e);
                }
            })
        });

        let toggleMenuTree = function (e) {
            $("#wrap").removeClass("scale-up").removeClass('display-nav').toggleClass('display-menu-tree');
            $("body").removeClass('display-nav').toggleClass('display-menu-tree');
            $(this).removeClass('hide');
            doTOCScrollEvent();
            if (window.innerWidth < 1000) {
                let post = $('#post');
                post.off('click').on('click', function(e){
                    post.off('click');
                    $('#wrap').removeClass('display-menu-tree').removeClass('display-nav');
                    $('body').removeClass('display-menu-tree').removeClass('display-nav');
                    e.preventDefault();
                });
                post.off('touchmove').on('touchmove', function(e){
                    post.off('click');
                    $('#wrap').removeClass('display-menu-tree').removeClass('display-nav');
                    $('body').removeClass('display-menu-tree').removeClass('display-nav');
                });
            }
        };
        $('#toggle-menu-tree').click(function (e) {
            toggleMenuTree(e);
        });
        scrollIndex = {};
        $('a.index-menu-link[href^="#menu_index_"]').each(function () {
            let linkHref = $(this).attr('href');
            if (linkHref.match(/menu_index_\d+/)) {
                $(this).click(function () {
                    Page.scrollPageTo(linkHref.substring(1), true);
                    if (window.innerWidth < 1000) {
                        $('#wrap').removeClass('display-menu-tree').removeClass('display-nav');
                        $('body').removeClass('display-menu-tree').removeClass('display-nav');
                    }
                });
                scrollIndex[parseInt($(linkHref).offset().top)] = linkHref;
            }
        });
        scrollIndexKeys = Object.keys(scrollIndex);
        scrollIndexKeys = scrollIndexKeys.sort(function (a, b) {
            return (a - b);
        });
        $('.index-menu>.index-menu-list>li.index-menu-item').each(function (index) {
            $(this).find('.index-menu-list').hide();
        });
    };
    let reCalcTOCIndex = function () {
        if (!LocalConst.SHOW_TOC) {
            return;
        }
        scrollIndex = {};
        $('a.index-menu-link[href^="#menu_index_"]').each(function () {
            var linkHref = $(this).attr('href');
            if (linkHref.match(/menu_index_\d+/)) {
                scrollIndex[parseInt($(linkHref).offset().top)] = linkHref;
            }
        });
        scrollIndexKeys = Object.keys(scrollIndex);
        scrollIndexKeys = scrollIndexKeys.sort(function (a, b) {
            return (a - b);
        });
    };
    let doTOCScrollEvent = function () {
        if (!LocalConst.SHOW_TOC) {
            return;
        }
        let scrollTop = $(window).scrollTop() + 100;
        if (scrollTop > 20) {
            $('#toggle-menu-tree').removeClass('revert');
        }
        if (!$('#wrap').hasClass('display-menu-tree')) {
            return;
        }
        let currentScrolledMenuIndex = 0;
        for(let i = 0; i < scrollIndexKeys.length; i++) {
            let key = scrollIndexKeys[i];
            if (key <= scrollTop) {
                currentScrolledMenuIndex = scrollIndex[key];
            } else {
                break;
            }
        }
        let current = $('.index-menu-item>a.index-menu-link[href="' + currentScrolledMenuIndex + '"]').first();
        let parent = current.parent().parent().parent();
        if (parent.hasClass('index-menu')) {
            parent = current.parent();
            parent.prev().find('.index-menu-list').hide();
            parent.next().find('.index-menu-list').hide();
            parent.find('.index-menu-list').show();
        } else {
            parent.prev().find('.index-menu-list').hide();
            parent.next().find('.index-menu-list').hide();
            parent.find('.index-menu-list').show();
            current.parent().find('.index-menu-list').show();
        }
        $('a.index-menu-link[href^="#menu_index_"]').each(function () {
            let linkHref = $(this).attr('href');
            if (linkHref.match(/menu_index_\d+/)) {
                $(this).parent().removeClass('current');
            }
        });
        current.parent().addClass('current');
    };
    let renderSmiles = function(message) {
        let matched;
        let subfix = "";
        if (window.devicePixelRatio !== undefined && window.devicePixelRatio >= 1.49) {
            subfix = "_2x";
        }
        while(matched=message.match(/@\(\s*(呵呵|哈哈|吐舌|太开心|笑眼|花心|小乖|乖|捂嘴笑|滑稽|你懂的|不高兴|怒|汗|黑线|泪|真棒|喷|惊哭|阴险|鄙视|酷|啊|狂汗|what|疑问|酸爽|呀咩爹|委屈|惊讶|睡觉|笑尿|挖鼻|吐|犀利|小红脸|懒得理|勉强|爱心|心碎|玫瑰|礼物|彩虹|太阳|星星月亮|钱币|茶杯|蛋糕|大拇指|胜利|haha|OK|沙发|手纸|香蕉|便便|药丸|红领巾|蜡烛|音乐|灯泡|开心|钱|咦|呼|冷|生气|弱|吐血)\s*\)/)) {
            message = message.replace(matched[0], "<img src=\"" + LocalConst.BIAOQING_PAOPAO_PATH + encodeURI(matched[1]).replace(/%/g, "") + subfix + ".png\" class=\"biaoqing newpaopao\" height=30 width=30 no-zoom />");
        }
        while(matched=message.match(/#\(\s*(高兴|小怒|脸红|内伤|装大款|赞一个|害羞|汗|吐血倒地|深思|不高兴|无语|亲亲|口水|尴尬|中指|想一想|哭泣|便便|献花|皱眉|傻笑|狂汗|吐|喷水|看不见|鼓掌|阴暗|长草|献黄瓜|邪恶|期待|得意|吐舌|喷血|无所谓|观察|暗地观察|肿包|中枪|大囧|呲牙|抠鼻|不说话|咽气|欢呼|锁眉|蜡烛|坐等|击掌|惊喜|喜极而泣|抽烟|不出所料|愤怒|无奈|黑线|投降|看热闹|扇耳光|小眼睛|中刀)\s*\)/)) {
            message = message.replace(matched[0], "<img src=\"" + LocalConst.BIAOQING_ARU_PATH + encodeURI(matched[1]).replace(/%/g, "") + subfix + ".png\" class=\"biaoqing alu\" height=33 width=33 no-zoom />");
        }
        if (typeof customRenderSmiles === 'function') {
            message = customRenderSmiles(message);
        }
        return message;
    };
    let loadCommentEmoji = function () {
        $('#comments').find('.comment-content>p').each(function (index, item) {
            $(item).html(renderSmiles($(item).html()));
        });

        let container = document.getElementsByClassName('OwO')[0];
        let target = document.getElementById('textarea');

        if (container !== undefined && target !== undefined) {
            var owo = new OwO({
                logo: '^_^',
                container: container,
                target: target,
                api: LocalConst.BASE_SCRIPT_URL + 'js/OwO.json',
                position: 'down',
                style: 'max-width: 100%;',
                maxHeight: '250px'
            });
        }
    };
    let loadDuoshuo = function(){
        DUOSHUO.EmbedThread($('.ds-thread'));
        DUOSHUO.ThreadCount($('.ds-thread-count'));
    };
    let setCookie = function(c_name,value,expireDays) {
        let exDate = new Date();
        exDate.setDate(exDate.getDate() + expireDays);
        let path = ';path=/';
        document.cookie = c_name + "=" + encodeURIComponent(value) + ((expireDays === null) ? "" : ";expires=" + exDate.toGMTString()) + path;
    };
    let bindReadSettingEvent = function () {
        // var switchToNightMode = function () {
        //     $('#side-toolbar-night-shift').removeClass().addClass('night-mode').attr('title', 'Night').find('i').removeClass().addClass('fa fa-moon-o');
        //     $('body').removeClass("theme-white").addClass("theme-dark");
        //     setCookie("MIRAGES_NIGHT_SHIFT_MODE", "NIGHT");
        // };
        // var switchToLightMode = function () {
        //     $('#side-toolbar-night-shift').removeClass().addClass('day-mode').attr('title', 'Light').find('i').removeClass().addClass('fa fa-sun-o');
        //     $('body').removeClass("theme-dark").addClass(LocalConst.LIGHT_THEME_CLASS);
        //     setCookie("MIRAGES_NIGHT_SHIFT_MODE", "DAY");
        // };
        // var switchToAutoMode = function () {
        //     var body = $('body');
        //     var btn = $('#side-toolbar-night-shift');
        //     btn.removeClass().addClass('auto-mode').attr('title', 'Auto').find('i').removeClass().addClass('fa fa-adjust');
        //     body.removeClass("theme-dark").addClass(LocalConst.LIGHT_THEME_CLASS);
        //     var hour = new Date().getHours();
        //     if (hour <= 5 || hour >= 22) {
        //         body.removeClass("theme-white").addClass("theme-dark");
        //         btn.addClass('night');
        //     } else {
        //         body.removeClass("theme-dark").addClass(LocalConst.LIGHT_THEME_CLASS);
        //     }
        //     setCookie("MIRAGES_NIGHT_SHIFT_MODE", "AUTO");
        // };
        $('#side-toolbar-read-settings').off('click').on('click', function (e) {
            let toolbar = $('#nav-toolbar').find('.side-toolbar');
            if (toolbar.hasClass("show-read-settings")) {
                $(this).parent().removeClass("selected");
                toolbar.removeClass("show-read-settings");
            } else {
                $(this).parent().addClass("selected");
                toolbar.addClass("show-read-settings");
            }
            // var btn = $(this);
            // var body = $('body');
            // console.log(LocalConst.AUTO_NIGHT_SHIFT);
            // if (btn.hasClass("auto-mode")) {
            //     if (btn.attr('data-prev-mode') == 'day-mode') {
            //         switchToNightMode();
            //     } else {
            //         if (body.hasClass("theme-dark")) {
            //             switchToLightMode();
            //         } else {
            //             if (LocalConst.AUTO_NIGHT_SHIFT) {
            //                 switchToNightMode();
            //             } else {
            //                 switchToLightMode();
            //             }
            //         }
            //     }
            //     btn.attr('data-prev-mode', 'auto-mode');
            // } else if (btn.hasClass("night-mode")) {
            //     if (LocalConst.AUTO_NIGHT_SHIFT) {
            //         if (btn.attr('data-prev-mode') == 'day-mode') {
            //             switchToAutoMode();
            //         } else {
            //             switchToLightMode();
            //         }
            //     } else {
            //         switchToLightMode();
            //     }
            //     btn.attr('data-prev-mode', 'night-mode');
            // } else if (btn.hasClass("day-mode")) {
            //     if (LocalConst.AUTO_NIGHT_SHIFT) {
            //         if (btn.attr('data-prev-mode') == 'night-mode') {
            //             switchToAutoMode();
            //         } else {
            //             switchToNightMode();
            //         }
            //     } else {
            //         switchToNightMode();
            //     }
            //     btn.attr('data-prev-mode', 'day-mode');
            // }
        });
        $('#page-read-setting-toggle').off('click').on('click', function (e) {
            $('#toggle-nav').trigger('click');

            let toolbar = $('#nav-toolbar').find('.side-toolbar');
            $('#side-toolbar-read-settings').parent().addClass("selected");
            toolbar.addClass("show-read-settings");
        });
    };
    let bindThemeChangeEvent = function () {
        let switchToNightMode = function () {
            // $('#side-toolbar-night-shift').removeClass().addClass('night-mode').attr('title', 'Night').find('i').removeClass().addClass('fa fa-moon-o');
            $('body').removeClass("theme-white").removeClass("theme-sunset").addClass("theme-dark");
            setCookie("MIRAGES_NIGHT_SHIFT_MODE", "NIGHT");
        };
        let switchToLightMode = function () {
            // $('#side-toolbar-night-shift').removeClass().addClass('day-mode').attr('title', 'Light').find('i').removeClass().addClass('fa fa-sun-o');
            $('body').removeClass("theme-dark").removeClass("theme-sunset").addClass(LocalConst.LIGHT_THEME_CLASS);
            setCookie("MIRAGES_NIGHT_SHIFT_MODE", "DAY");
        };
        let switchToSunsetMode = function () {
            // $('#side-toolbar-night-shift').removeClass().addClass('day-mode').attr('title', 'Light').find('i').removeClass().addClass('fa fa-sun-o');
            $('body').removeClass("theme-dark").addClass(LocalConst.LIGHT_THEME_CLASS).addClass("theme-sunset");
            setCookie("MIRAGES_NIGHT_SHIFT_MODE", "SUNSET");
        };
        let switchToAutoMode = function () {
            let body = $('body');
            let btn = $('#side-toolbar-night-shift');
            // btn.removeClass().addClass('auto-mode').attr('title', 'Auto').find('i').removeClass().addClass('fa fa-adjust');
            body.removeClass("theme-dark").addClass(LocalConst.LIGHT_THEME_CLASS);
            let hour = new Date().getHours();
            if (hour <= 5 || hour >= 22) {
                body.removeClass("theme-white").removeClass("theme-sunset").addClass("theme-dark");
                btn.addClass('night');
            } else {
                body.removeClass("theme-dark").removeClass("theme-sunset").addClass(LocalConst.LIGHT_THEME_CLASS);
            }
            setCookie("MIRAGES_NIGHT_SHIFT_MODE", "AUTO");
        };
        $('a.background-color-control').off('click').on('click', function (e) {
            $('a.background-color-control').removeClass("selected");
            $(this).addClass("selected");
            let mode = $(this).attr('data-mode');
            if (mode === 'auto') {
                switchToAutoMode();
            } else if (mode === 'white') {
                switchToLightMode();
            } else if (mode === 'sunset') {
                switchToSunsetMode();
            } else if (mode === 'dark') {
                switchToNightMode();
            }
        });
    };
    let bindSwitchFontFamily = function () {
        $('button.font-family-control').off('click').on('click', function (e) {
            let mode = $(this).attr('data-mode');
            if (mode === 'serif') {
                Page.switchToSerifFonts();
            } else if (mode === 'sans-serif') {
                Page.switchToSansSerifFonts();
            }
        });
    };
    let hideSPProgress = function (delay) {
        delay = delay || 0;
        setTimeout(function () {
            $(".sp-progress").css("opacity", "0");
        }, delay);
    };
    let bindFontSizeControl = function () {
        let display = $('#font-size-display');
        let updateFontSizeDisplay = function () {
            let fontSize = LocalConst.ROOT_FONT_SIZE;
            let percent = parseInt(fontSize);
            display.text(percent + "%");
        };
        let changeFontSizeByPercent = function (percent) {
            let changed = parseInt($('#font-size-display').text());
            changed = changed + percent;
            if (changed < 80 || changed > 200) {
                return;
            }
            $('html').css('font-size', changed + '%');
            display.text(changed + "%");
            setCookie("MIRAGES_ROOT_FONT_SIZE", changed);
        };
        updateFontSizeDisplay();
        $('.font-size-control').off('click').on('click', function (e) {
            let mode = $(this).attr('data-mode');
            if (mode === 'smaller') {
                changeFontSizeByPercent(-5)
            } else if (mode === 'larger') {
                changeFontSizeByPercent(5)
            }
        });
    };
    let setupAsyncLoadEvent = function () {
        let asyncStartTime = new Date();
        window.asyncBannerLoadNum = 0;
        window.asyncBannerLoadCompleteNum = 0;
        window.asyncImageLoadNum = 0;
        window.asyncImageLoadCompleteNum = 0;

        let ajaxDone = function (event) {
            Mlog(event.type.toUpperCase());
            if (window.asyncBannerLoadNum === window.asyncBannerLoadCompleteNum
                && window.asyncImageLoadNum === window.asyncImageLoadCompleteNum
                && window.asyncBannerLoadNum === window.asyncImageLoadNum
                && window.asyncImageLoadNum === -1170) {
                let time = new Date() - asyncStartTime;
                Mlog("All Done[" + time + "ms][" + event.type.toUpperCase() + "]");
                let delay = (time < 1170) ? (1170 - time) : 0;
                hideSPProgress(delay);
            }
        };

        $('body').off("ajax-image:done").on("ajax-image:done", ajaxDone)
            .off("ajax-banner:done").on("ajax-banner:done", ajaxDone);
    };
    window['Page'] = {
        setupLazyLoadImage: function () {
            $("section.lazy-load").each(function () {
                if (window.asyncImageLoadNum >= 0) {
                    window.asyncImageLoadNum ++;
                    Mlog("Loading..." + window.asyncImageLoadNum);
                }
                let section = $(this);
                let container = section.find(".progressiveMedia");
                let small = container.find(".img-small");

                let cdnType = section.attr('data-' + LocalConst.KEY_CDN_TYPE);
                let addOn = getImageAddon(cdnType);

                let largeImage = new Image();
                largeImage.src = small.attr('data-src') + addOn;
                largeImage.classList.add('img-large');
                $(largeImage).attr('no-zoom', true);
                largeImage.onload = function () {
                    container.addClass('large-image-loaded');
                    setTimeout(function () {
                        $(largeImage).addClass("loaded")
                            .attr('data-action', 'zoom')
                            .removeAttr('no-zoom')
                            .removeAttr('width')
                            .removeAttr('height')
                            .css('height', '')
                            .attr('data-shadow', section.attr('data-shadow'));
                        // .css('width', section.css('width'))
                        // .css('height', section.css('height'));

                        section.replaceWith($(largeImage));
                        if (window.asyncImageLoadCompleteNum >= 0) {
                            window.asyncImageLoadCompleteNum ++;
                            Mlog("Loaded: " + window.asyncImageLoadCompleteNum);
                            if (window.asyncImageLoadCompleteNum === window.asyncImageLoadNum) {
                                window.asyncImageLoadNum = -1170;
                                window.asyncImageLoadCompleteNum = -1170;
                                $('body').trigger("ajax-image:done");
                            }
                        }
                    }, 1001);
                };
                container.append(largeImage);
            });
            if (!isNaN(window.asyncImageLoadNum) && window.asyncImageLoadNum === 0) {
                Mlog("Async Image Nothing to Load");
                window.asyncImageLoadNum = -1170;
                window.asyncImageLoadCompleteNum = -1170;
                $('body').trigger("ajax-image:done");
            }
        },
        setupCDNImageOptimize: function () {
            $("article img:not(code img, pre img, .lazy-load img)").each(function() {
                let src = $(this).attr('data-src');
                let cdnType = $(this).attr('data-' + LocalConst.KEY_CDN_TYPE);
                let addOn = getImageAddon(cdnType);
                if (src !== null && src !== undefined && src !== "") {
                    $(this).attr('src', src + addOn);
                    $(this).removeAttr('data-src');
                }
            });

        },
        loadDisqus: function () {
            if($('#disqus_thread').length) {
                if(window.DISQUS) {
                    DISQUS.reset({
                        reload: true
                    });
                } else {
                    let dsq = document.createElement('script'); dsq.type = 'text/javascript'; dsq.async = true;
                    dsq.src = '//' + LocalConst.DISQUS_SHORT_NAME + '.disqus.com/embed.js';
                    (document.getElementsByTagName('head')[0] || document.getElementsByTagName('body')[0]).appendChild(dsq);
                }
            }
        },
        scrollPageTo: function(id, animated) {
            id = isNaN(id) ? $('#' + id).offset().top : id;
            let time = (animated !== undefined && animated === true) ? 600 : 0;
            $("body,html").animate({
                scrollTop: id
            }, time);
            return false;
        },
        autoScrollPage: function() {
            let anchor = location.hash.indexOf('#'); // 用indexOf检查location.href中是否含有'#'号，如果没有则返回值为-1
            if (anchor < 0) {
                return;
            }
            anchor = window.location.hash.substring(anchor + 1);
            this.scrollPageTo(anchor);
        },
        setupContents: function () {
            $("article img:not(article .link-box img, img[no-zoom])").each(function() {
                $(this).attr('data-action', 'zoom');
                if($(this).next().is('br')){
                    $(this).next().remove();
                }
            });
            $(".post-content a:not(code a, pre a), #content a:not(code a, pre a), #comments a").each(function() {
                let href = $(this).attr('href');
                if (href.startWith("http") && !href.startWith(location.origin)) {
                    $(this).attr('target', "_blank");
                }
            });
            $(".post-content p.more a").each(function() {
                $(this).removeAttr("target")
            });
            $("li.task-list-item").each(function () {
                let parent = $(this).parent();
                if (!parent.hasClass("task-list")) {
                    parent.addClass("task-list")
                }
            });
            $(".post-content table").wrap("<div class='table-responsive'></div>");
            $(".post-content embed.video-4-3, .post-content embed.video").wrap("<div class='video-container video-4-3'></div>");
            $(".post-content embed.video-16-9").wrap("<div class='video-container video-16-9'></div>");
        },
        highlightCodeBlock: function () {
            if (LocalConst.ENABLE_FLOW_CHART) {
                $('pre>code.lang-flow').each(function (index) {
                    $(this).addClass('nohighlight')
                        .attr('data-flow-chart-index', index)
                        .parent()
                        .addClass('display-none')
                        .after('<div id="flow-chart-' + index + '" class="flow-chart"></div>');
                });
            }
            $('pre code').each(function(i, block) {
                hljs.highlightBlock(block);
            });
        },
        renderFlowChart: function () {
            $('pre>code.lang-flow').each(function () {
                let index = $(this).attr('data-flow-chart-index');
                let code = this.innerText;

                if (typeof code !== 'undefined') {
                    let lineWidth = 2;
                    if (window.devicePixelRatio !== undefined && window.devicePixelRatio >= 1.49) {
                        lineWidth = 1.5;
                    }
                    let diagram = flowchart.parse(code);
                    let config = {
                        'x': 0,
                        'y': 0,
                        'line-width': lineWidth,
//                        'maxWidth': 2,//ensures the flowcharts fits within a certian width
//                        'line-length': 50,
                        'text-margin': 15,
                        'font-size': 13,
                        'font': 'normal',
                        'font-family': 'Consolas, Menlo, Monaco, "lucida console", "Liberation Mono", "Courier New", "andale mono", monospaceX, sans-serif',
                        'font-weight': 'normal',
                        'fill': 'none',
                        'yes-text': 'yes',
                        'no-text': 'no',
                        'arrow-end': 'block',
                        'scale': 1,
                    };
                    if ($(body).hasClass("theme-dark")) {
                        config['line-color'] = 'white';
                        config['element-color'] = 'white';
                        config['font-color'] = 'white';
                    }
                    diagram.drawSVG('flow-chart-' + index, config);
                }

                $(this).parent().remove();
            })
        },
        resetStatus: function () {
            $('#wrap').removeClass('display-nav').removeClass('display-menu-tree');
            $('#footer').removeClass('display-nav');
            $('#body').off('click');
            $('body').removeClass('show-reward-qr-box').removeClass('show-post-qr-box').removeClass('display-nav').removeClass('display-menu-tree');
            offBodyHeightChange();
        },
        bindQRCodeBlockEvents: function () {
            $('#toggle-post-qr-code').off('click').on('click', function (e) {
                $('body').removeClass('show-reward-qr-box').toggleClass('show-post-qr-box');
            });
            $('#toggle-reward-qr-code').off('click').on('click', function (e) {
                $('body').removeClass('show-post-qr-box').toggleClass('show-reward-qr-box');
            });
        },


        reInitAPlayer: function () {
            if ('undefined' === typeof(APlayerOptions) || 'undefined' === typeof(APlayers)) {
                return;
            }
            let len = APlayerOptions.length;
            for(let i=0;i<len;i++){
                APlayers[i] = new APlayer({
                    element: document.getElementById('player' + APlayerOptions[i]['id']),
                    narrow: false,
                    preload: APlayerOptions[i]['preload'],
                    mutex: APlayerOptions[i]['mutex'],
                    autoplay: APlayerOptions[i]['autoplay'],
                    showlrc: APlayerOptions[i]['showlrc'],
                    music: APlayerOptions[i]['music'],
                    theme: APlayerOptions[i]['theme']
                });
                APlayers[i].init();
            }
        },
        reInitDPlayer: function () {
            if ('undefined' === typeof(dPlayerOptions) || 'undefined' === typeof(dPlayers)) {
                return;
            }
            let len = dPlayerOptions.length;
            for(let i = 0; i < len; i++){
                let ele = document.getElementById('player' + dPlayerOptions[i]['id']);
                if ('undefined' === typeof(ele) || ele === null) {
                    continue;
                }
                dPlayers[i] = new DPlayer({
                    element: ele,
                    autoplay: dPlayerOptions[i]['autoplay'],
                    video: dPlayerOptions[i]['video'],
                    theme: dPlayerOptions[i]['theme'],
                    danmaku: dPlayerOptions[i]['danmaku']
                });
            }
        },
        switchToSerifFonts: function () {
            setCookie("MIRAGES_USE_SERIF_FONTS", "1");
            if (typeof(Typekit) === 'undefined') {
                Page.loadTypeKitService();
            }
            $('body').addClass("serif-fonts");
            $('.font-family-control').removeClass("selected");
            $('.font-family-control.control-btn-serif').addClass("selected");
            alert(LocalConst.SERIF_LOAD_NOTICE);
        },
        switchToSansSerifFonts: function () {
            setCookie("MIRAGES_USE_SERIF_FONTS", "");
            $('body').removeClass("serif-fonts");
            $('.font-family-control').removeClass("selected");
            $('.font-family-control.control-btn-sans-serif').addClass("selected");
        },
        loadTypeKitService: function () {
            (function(d) {
                let config = LocalConst.TYPEKIT_CONFIG,
                    h=d.documentElement,t=setTimeout(function(){h.className=h.className.replace(/\bwf-loading\b/g,"")+" wf-inactive";},config.scriptTimeout),tk=d.createElement("script"),f=false,s=d.getElementsByTagName("script")[0],a;h.className+=" wf-loading";tk.src='https://use.typekit.net/'+config.kitId+'.js';tk.async=true;tk.onload=tk.onreadystatechange=function(){a=this.readyState;if(f||a&&a!="complete"&&a!="loaded")return;f=true;clearTimeout(t);try{Typekit.load(config)}catch(e){}};s.parentNode.insertBefore(tk,s)
            })(document);
        },
        showReadSettings: function (value) {
            setCookie("SHOW_READ_SETTINGS", value);
        },
        doPJAXClickAction: function () {
            setupAsyncLoadEvent();
            $('body').attr('data-prev-href', document.location.pathname + document.location.search + document.location.hash).removeClass('display-menu-tree');
            $('#wrap').removeClass('display-menu-tree');
            if (LocalConst.PJAX_LOAD_STYLE === LocalConst.PJAX_LOAD_STYLE_SIMPLE) {
                $(".sp-progress").css("opacity", "1");
            }
        },
        doPJAXSendAction: function () {
            if (LocalConst.PJAX_LOAD_STYLE === LocalConst.PJAX_LOAD_STYLE_SIMPLE) {
            } else if (LocalConst.PJAX_LOAD_STYLE === LocalConst.PJAX_LOAD_STYLE_CIRCLE) {
                $('#loader-wrapper').addClass("in");
            }
            Page.resetStatus();
        },
        doPJAXCompleteAction: function () {
            if (LocalConst.PJAX_LOAD_STYLE === LocalConst.PJAX_LOAD_STYLE_SIMPLE) {
            } else if (LocalConst.PJAX_LOAD_STYLE === LocalConst.PJAX_LOAD_STYLE_CIRCLE) {
                $('#loader-wrapper').removeClass("in");
            }
            bindReadSettingEvent();
            let body = $('body');
            let refer = body.attr('data-prev-href');
            let currentHref = document.location.pathname + document.location.search + document.location.hash;
            _czc.push(['_trackPageview', currentHref, refer]);
            _hmt.push(['_trackPageview', currentHref]);
            pangu.spacingElementById('body');
            if (!isNaN(window.asyncBannerLoadNum) && window.asyncBannerLoadNum === 0) {
                Mlog("Async Banner Nothing to Load");
                window.asyncBannerLoadNum = -1170;
                window.asyncBannerLoadCompleteNum = -1170;
                body.trigger("ajax-banner:done");
            }
            this.setupLazyLoadImage();
            this.setupCDNImageOptimize();
            this.setupContents();
            this.highlightCodeBlock();
            this.bindQRCodeBlockEvents();
            this.autoScrollPage();
            bindTOCEvent();
            this.renderFlowChart();
            this.reInitAPlayer();
            this.reInitDPlayer();
            if (LocalConst.COMMENT_SYSTEM === LocalConst.COMMENT_SYSTEM_DISQUS) {
                this.loadDisqus();
            } else if (LocalConst.COMMENT_SYSTEM === LocalConst.COMMENT_SYSTEM_EMBED) {
                bindAjaxComment();
                loadCommentEmoji();
            }
            // if (LocalConst.PJAX_LOAD_STYLE === LocalConst.PJAX_LOAD_STYLE_SIMPLE) {
            //     hideSPProgress(600);
            // }
        }
    };
    String.prototype.startWith = function(str){
        if (str === null || str === "" || this.length === 0 || str.length > this.length) {
            return false;
        }
        return this.substr(0, str.length) === str;
    };
})(jQuery);
