<?php
if (!defined('__TYPECHO_ROOT_DIR__')) exit;

/**
 * en.php
 * Author     : Hran
 * Date       : 2016/12/11
 * Version    :
 * Description:
 */
class Lang_Settings_en extends Lang {

    /**
     * @return string 返回语言名称
     */
    public function name() {
        return "English";
    }

    /**
     * @return array 返回包含翻译文本的数组
     */
    public function translated() {
        return array(
            // function
            '主题外观' => 'Appearance',
            '主题基础色调' => 'Base Theme',
            '默认为 Mirages White' => 'Default: Mirages White',
            '自动夜间模式' => 'Night Shift',
            '开启' => 'On',
            '关闭' => 'Off',
            '是' => 'Yes',
            '否' => 'No',
            'Banner 下边界添加弧型遮罩' => 'Show Curve at banner bottom.',
            '默认不添加弧型遮罩' => 'Default is no.',
            '自定义颜色' => 'Custom Colors',
            '自定义主题主色调' => 'Custom Main Color',
            '自定义 Selection Color' => 'Custom Selection Color',
            '自定义 Selection Background Color' => 'Selection Background Color',
            '首页配图' => 'Images',
            '站点背景大图地址' => 'Background Image At Index Page',
            '站点背景大图高度(%)' => 'Image Height At Index Page',
            '请仅输入数字' => 'Please input number only',
            '侧边栏头像' => 'Head Photo',
            '界面语言' => 'Language',
            '侧边栏' => 'Side Menu',
            '始终显示 Dashboard(控制台) 菜单' => 'Always show dashboard in side menu.',
            '侧边栏底部按钮' => 'Side Toolbar',
            'Disqus 评论' => 'Disqus Comment',
            '相关文档' => 'Reference Documents',
            '评论 - Disqus' => 'Comment - Disqus',
            '评论 - 多说' => 'Comment - Duoshuo',
            '多说 Short Name' => 'Duoshuo Short Name',
            '多说评论' => 'Duoshuo Comment',
            '多说 User Id' => 'Duoshuo User Id',
            '自定义多说 Embed.js' => 'Custom Duoshuo Embed.js',
            '自定义多说 Author Id' => 'Custom Duoshuo Author Id',
            '二维码及打赏' => 'QR Code And Reward',
            '本页二维码生成地址' => 'QR Code Generator URL',
            '打赏二维码图片地址' => 'Reward QR Code URL',
            '速度优化' => 'Speed Optimize',
            '静态文件路径' => 'Static file path',
            '主题内置' => 'Embed',
            'Google 字体' => 'Google Fonts',
            '主题字体加载方式' => 'Web Fonts Source',
            '扩展功能' => 'Extension',
            '显示数学公式 (MathJax)' => 'Parse And Show MathJAX',
            '数学公式支持' => 'MathJAX Supports',
            'Markdown 语法扩展' => 'Markdown Language Extends',
            '不启用' => 'Disable',
            '启用 PJAX (BETA)' => 'Enable PJAX (BETA)',
            '高级选项' => 'Advance Settings',
            '其他选项' => 'Others Settings',
            '为 Windows 平台的 Chrome 浏览器启用平滑滚动' => 'Enable Smooth Scroll For Chrome On Windows',


            '感谢您使用 Mirages' => 'Thanks for using Mirages',
            '主题帮助文档' => 'Documents',
            '意见或建议' => 'Feedback',
            '版本: ' => 'Version: ',
            '你可以到这里查看主题的最新版本' => 'Get latest version',
            '当前已为最新版' => 'Latest version',
        );
    }

    /**
     * @return string 返回日期的格式化字符串
     */
    public function dateFormat() {
        return "F j, Y";
    }
}