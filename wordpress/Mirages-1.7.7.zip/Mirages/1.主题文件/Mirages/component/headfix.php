<?php if (!defined('__TYPECHO_ROOT_DIR__')) exit; ?>
<style type="text/css">
    body, button, input, optgroup, select, textarea,
    body.serif-fonts .post-content h1, body.serif-fonts .comment-content h1,
    body.serif-fonts .post-content h2, body.serif-fonts .comment-content h2,
    body.serif-fonts .post-content h3, body.serif-fonts .comment-content h3,
    body.serif-fonts .post-content h4, body.serif-fonts .comment-content h4,
    body.serif-fonts .post-content h5, body.serif-fonts .comment-content h5,
    body.serif-fonts .post-content h6, body.serif-fonts .comment-content h6 {
        font-family: 'Mirages Custom', 'Merriweather', 'Open Sans', <?php echo I18n::fontFamily();?> 'Segoe UI Emoji', 'Segoe UI Symbol', Helvetica, Arial, sans-serif;
    }
    .github-box, .github-box .github-box-title h3 {
        font-family: 'Mirages Custom', 'Merriweather', 'Open Sans', <?php echo I18n::fontFamily();?> 'Segoe UI Emoji', 'Segoe UI Symbol', Helvetica, Arial, sans-serif !important;
    }
    .aplayer {
        font-family: 'Mirages Custom', 'Myriad Pro', 'Myriad Set Pro', 'Open Sans', <?php echo I18n::fontFamily();?> Helvetica, arial, sans-serif !important;
    }
    body.content-lang-en.content-serif .post-content {
        font-family: 'Lora', 'PT Serif', 'Source Serif Pro', Georgia, <?php echo I18n::fontFamily();?> serif;
    }
    /* Serif */
        body.serif-fonts .post-content {
            font-family: <?php echo I18n::serifFontFamily(); ?> Georgia, serif;
        }
    /*}*/
</style>
<style type="text/css">
    /*根据操作系统及浏览器进行样式修正*/
    <?php if(Device::isSafari()):?>
        <?php if (false && Device::isMacOSX()):?>
        pre::-webkit-scrollbar {
            height:8px;
            width:8px;
        }
        pre::-webkit-scrollbar-thumb {
            -webkit-box-shadow:inset 1px 1px 0 rgba(0,0,0,.1),inset 0 -1px 0 rgba(0,0,0,.07);
            background-clip:padding-box;
            background-color:#808080;
            min-height:40px;
            padding-top:100px;
            border-radius: 4px;
        }
        pre::-webkit-scrollbar-thumb:hover,
        pre::-webkit-scrollbar-thumb:active {
            background-color:#B3B3B3;
        }
        body.theme-dark pre::-webkit-scrollbar {
            height:8px;
            width:8px;
        }
        body.theme-dark pre::-webkit-scrollbar-thumb {
            -webkit-box-shadow:inset 1px 1px 0 rgba(0,0,0,.1),inset 0 -1px 0 rgba(0,0,0,.07);
            background-clip:padding-box;
            background-color: #696969;
            min-height:40px;
            padding-top:100px;
            border-radius: 4px;
        }
        body.theme-dark pre::-webkit-scrollbar-thumb:hover, body.theme-dark pre::-webkit-scrollbar-thumb:active {
            background-color:#959595;
        }
        <?php endif;?>

        body.card #index article .post-card, body.card #archive article .post-card {
            -webkit-transition: .3s ease transform;
            -moz-transition: .3s ease transform;
            -ms-transition: .3s ease transform;
            -o-transition: .3s ease transform;
            transition: .3s ease transform;
        }
    <?php endif?>
</style>
<style type="text/css">
    /** 页面样式调整 */
    <?php if(!Utils::hasValue(Mirages::$options->postQRCodeURL) || !Utils::hasValue(Mirages::$options->rewardQRCodeURL)): ?>
    .post-buttons a {
        width: -webkit-calc(100% / 2 - .3125rem);
        width: calc(100% / 2 - .3125rem);
    }
    <?php endif?>

    <?php if (Utils::isTrue(Mirages::$options->greyBackground)):?>
    #wrap, .inner::after, #masthead::after,body.theme-white #footer, body.theme-white div#body-bottom,
    .post-content table tr, body.theme-white #comments .comment-list li.comment-level-even{
        background-color: #f0f0f0;
    }
    .post-content table thead>tr, .post-content table tr:nth-child(2n), .img-box{
        background-color: #eaeaea;
    }
    body.theme-white #comment-form input, body.theme-white #comment-form textarea,.post-content .highlight pre, .post-content pre {
        background-color: rgba(0,0,0,0.04);
    }
    .post-buttons a, body.theme-white .post-near,body.theme-white #comments>.comment-list>.comment-body>.comment-children>.comment-list {
        border-color: rgba(0,0,0,0.04);
    }
    body.theme-white #comment-form input#submit {
        background: #eaeaea repeating-linear-gradient(-45deg, #f0f0f0, #f0f0f0 1.125rem, transparent 1.125rem, transparent 2.25rem);
    }
    .post-content hr {
        background: #ddd repeating-linear-gradient(-45deg, #f0f0f0, #f0f0f0 .25rem, transparent .25rem, transparent .5rem)
    }
    <?php endif?>
    <?php if(Utils::hasValue(Mirages::$options->codeColor)):?>
    .post .post-content>*:not(pre) code {
        color: <?php echo Mirages::$options->codeColor?>;
    }
    <?php endif;?>
</style>
<?php
if(Utils::isHexColor(Mirages::$options->themeColor)) {
    $this->need('component/head_colors.php');
}
?>
<?php echo "\n"; ?>
<?php echo Utils::replaceStaticPath(Mirages::$options->customHTMLInHeadBottom); ?>
<script>
    var _czc = _czc || [];
    var _hmt = _hmt || [];
</script>
