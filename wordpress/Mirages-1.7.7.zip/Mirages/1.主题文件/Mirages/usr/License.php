<?php
if (!defined('__TYPECHO_ROOT_DIR__')) exit;

/**
 * License.php
 * Author     : Hran
 * Date       : 2018/07/28
 * Version    :
 * Description:
 */
class License {
    static $name = "Mirages";
    static $pk = "dnRQZU5pOjE1MzI3NTE0NDQ6MGVmZTE5Yjg4N2I1YjRiZjdjZDc3OTg0ZDgyNDI2ZjY1";
}
