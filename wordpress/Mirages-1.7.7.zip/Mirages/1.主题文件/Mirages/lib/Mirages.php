<?php
if (!defined('__TYPECHO_ROOT_DIR__')) exit;

/**
 * Mirages.php
 * Author     : Hran
 * Date       : 2016/12/10
 * Version    :
 * Description:
 */
class Mirages {
    public static $version = "1.7.7";
    public static $versionTag = "1.7.7";

    private static $canParseBiaoqing = -1;
    private static $pluginVersion = -1;

    /**
     * @var Mirages_Settings|mixed
     */
    public static $options = NULL;

    static function init() {
        if (self::$options != NULL) {
            return;
        }
        self::$options = Mirages_Settings::instance();
        self::$options->loadDefaultSettings();
        self::$options->loadSettings(self::$options->realRealRealRealAdvancedOptions);
    }

    static function initTheme(Widget_Archive $archive) {
        $options = self::$options;
        if ($options == NULL) {
            self::init();
        }

        $db = Typecho_Db::get();
        $options->userNum = $db->fetchObject($db->select(array('COUNT(uid)' => 'num'))->from('table.users'))->num;
        if($archive->is("index")){
            $options->banner = self::randomBanner(Utils::replaceStaticPath($options->defaultBg));
        } else {
            $options->banner = self::randomBanner(self::loadArchiveBanner($archive));
        }
        $position = self::getBannerPosition($options->banner);
        $options->banner = $position[0];
        $options->bannerPosition = $position[1];
        $options->showBanner = ($options->headTitle__isTrue || (strlen($options->banner) > 5) || $archive->is('page','about') || $archive->is('page','links'));
        if (!($archive->is("index") || $archive->is("archive")) && $options->headTitle__isFalse && Utils::isTrue($archive->fields->disableBanner)) {
            $options->showBanner = FALSE;
        }
        if (!($archive->is("index") || $archive->is("archive")) && (Utils::isTrue($archive->fields->disableBanner) || strlen($options->banner) <= 5)) {
            $options->noBannerImage = TRUE;
        }
        if(Utils::isHexColor($options->themeColor)) {
            $options->colorClass = "color-custom";
        } else {
            $options->colorClass = "color-default";
        }
        if ($options->codeBlockOptions__codeDark) {
            $options->colorClass = $options->colorClass . " code-dark";
        }
        $bgHeight = $options->defaultBgHeight;
        if ($archive->is('single') && Utils::hasValue($archive->fields->bannerHeight)) {
            $bgHeight = $archive->fields->bannerHeight;
        }
        $mobileBGHeight = $options->defaultMobileBgHeight;
        if ($archive->is('single') && Utils::hasValue($archive->fields->mobileBannerHeight)) {
            $mobileBGHeight = $archive->fields->mobileBannerHeight;
        }
        $options->bannerHeight = $bgHeight;
        $options->mobileBannerHeight = $mobileBGHeight;
        define("FULL_BANNER_DISPLAY", (intval($bgHeight) >= 100 || intval($mobileBGHeight) >= 100));

        if (Utils::hasValue($options->sideMenuAvatar)) {
            $headFace = Utils::replaceStaticPath($options->sideMenuAvatar);
        } else {
            if ($options->currentUser->hasLogin()) {
                $mail = $options->currentUser->mail;
            } else {
                $db = Typecho_Db::get();
                $user = $db->fetchAll($db->select()->from('table.users')->order('UID')->limit(1));
                $user = $user[0];
                $mail = @$user['mail'];
            }
            $headFace = Typecho_Common::gravatarUrl($mail, 200, $options->commentsAvatarRating, NULL, true);
        }
        $options->headFaceUrl = $headFace;

        if ($archive->is('single')) {
            if (intval($archive->fields->TOC) > 0) {
                $showTOC = intval($archive->fields->TOC);
            } else {
                $showTOC = intval($archive->fields->showTOC);
            }
            $options->showTOC = $showTOC;
            if ($options->showTOC && in_array(intval(Mirages::$options->TOCDisplayMode), array(Mirages_Const::TOC_DEFAULT_SHOW_AT_RIGHT, Mirages_Const::TOC_DEFAULT_SHOW_AT_LEFT, Mirages_Const::TOC_ALWAYS_SHOW_AT_RIGHT, Mirages_Const::TOC_ALWAYS_SHOW_AT_LEFT))) {
                $options->defaultTOCClass = "display-menu-tree";
            } else {
                $options->defaultTOCClass = "";
            }

            if ($options->showTOC && in_array(intval(Mirages::$options->TOCDisplayMode), array(Mirages_Const::TOC_ALWAYS_SHOW_AT_RIGHT, Mirages_Const::TOC_ALWAYS_SHOW_AT_LEFT))) {
                $options->needHideToggleTOCBtn = true;
            }

            if ($options->showTOC && in_array(intval(Mirages::$options->TOCDisplayMode), array(Mirages_Const::TOC_DEFAULT_SHOW_AT_LEFT, Mirages_Const::TOC_ALWAYS_SHOW_AT_LEFT))) {
                $options->showTOCAtLeft = true;
            }
        } else {
            $options->showTOC = 0;
            $options->defaultTOCClass = "";
        }

        $bodyClass = THEME_CLASS;
        $bodyClass .= (USE_SERIF_FONTS ? " serif-fonts" : "");
        $bodyClass .= " " . $options->colorClass;
        $bodyClass .= $options->useCardView__isTrue ? ' card ' : '';
        $bodyClass .= Device::isMobile() ? ' mobile' : ' desktop';
        $bodyClass .= Device::isWindows() ? ' windows' : '';
        $bodyClass .= Device::isWindowsBlowWin8() ? ' windows-le-7' : '';
        $bodyClass .= Device::isMacOSX() ? ' macOS' : '';
        $bodyClass .= Device::isELCapitanOrAbove() ? ' macOS-ge-10-11' : '';
        $bodyClass .= Device::isSierraOrAbove() ? ' macOS-ge-10-12' : '';
        $bodyClass .= (Device::is('Chrome', 'Edge') || Device::is(array('Chrome', 'OPR'))) ? ' chrome' : '';
        $bodyClass .= Device::isPhone() ? ' phone' : '';
        $bodyClass .= Device::is("iPad") ? ' ipad' : '';
        $bodyClass .= Device::isSafari() ? ' safari' : ' not-safari';
        $bodyClass .= Device::is('Android') ? ' android' : '';
        $bodyClass .= Device::is('Edge') ? ' edge' : '';
        $bodyClass .= $options->codeBlockOptions__codeWrapLine ? ' wrap-code' : '';
        if ('zh' !== strtolower($archive->fields->contentLang)) {
            if ('en' == strtolower($archive->fields->contentLang) || 'en' == strtolower($options->contentLang)) {
                $bodyClass .= ' content-lang-en';
            } elseif ('en_serif' == strtolower($archive->fields->contentLang) || 'en_serif' == strtolower($options->contentLang)) {
                $bodyClass .= ' content-lang-en content-serif';
            }
        }

        $options->bodyClass = $bodyClass;
    }

    static function loadArchiveBanner($archive) {

        if (count($archive->stack) == 1) {
            if (Utils::hasValue($archive->fields->banner)) {
                return $archive->fields->banner;
            } else {
                return "";
            }
        } else {
            $cids = array();
            // 略过第一篇文章的大图
            for($i = 1; $i < count($archive->stack); $i++) {
                $cids[] = $archive->stack[$i]["cid"];
            }
            if (count($cids) < 1) {
                return "";
            }
            $db = Typecho_Db::get();
            $rows = $db->fetchAll($db->select()->from('table.fields')
                ->where('cid IN ?', $cids)
                ->where('name = ?', 'banner')
                ->where("TRIM(str_value) != ''")
            );

            $banners = array();
            foreach ($rows as $row) {
                $banners[] = $row[$row['type'] . '_value'];
            }
            if (count($banners) == 1) {
                return $banners[0];
            } elseif (count($banners) == 0) {
                return "";
            } else {
                return $banners[count($banners) - 1];
            }
        }
    }

    static function randomBanner($banners) {
        $banners = mb_split("\n", $banners);
        $banner = $banners[rand(0, count($banners) - 1)];
        $banner = trim($banner);
        return $banner;
    }

    static function getBannerPosition($banner) {
        if (Utils::startsWith($banner, "[")) {
            $index = strpos($banner, ']');
            if (false !== $index) {
                $position = substr($banner, 1, $index - 1);
                $banner = substr($banner, $index + 1);

                $position = explode(',', $position);
                $position = array_unique($position);
                $position = join(' ', $position);
                return array($banner, trim(strtoupper($position)));
            }
        }
        return array($banner, "");
    }

    static function parseBiaoqing($content) {
        if (self::$canParseBiaoqing < 0) {
            if (!self::pluginAvailable(100)) {
                self::$canParseBiaoqing = 0;
                return $content;
            }
            if (!method_exists("Mirages_Plugin", "parseBiaoqing")) {
                self::$canParseBiaoqing = 0;
                return $content;
            }
            self::$canParseBiaoqing = 1;
        } elseif (self::$canParseBiaoqing === 0) {
            return $content;
        }
        $content = Mirages_Plugin::parseBiaoqing($content);
        return $content;
    }

    static function pluginAvailable($version) {
        $need = intval($version);
        if (self::$pluginVersion < 0) {
            self::$pluginVersion = 0;
            if (class_exists("Mirages_Plugin")) {
                $plugins = Typecho_Plugin::export();
                $plugins = $plugins['activated'];
                if (is_array($plugins) && array_key_exists('Mirages', $plugins)) {
                    self::$pluginVersion = Mirages_Plugin::VERSION;
                }
            }
        }
        return self::$pluginVersion >= $need;
    }

    static function pluginAvailableMessage($version, $versionTag, $templateMessage = NULL) {
        if ($templateMessage == NULL) {
            $templateMessage = "<br><span style=\"font-weight: bold;color: red\">当前 Mirages 插件版本过低，使用此功能需要 Mirages 插件 %s 或以上版本。</span>";
        }
        if (!class_exists("Mirages_Plugin")) {
            self::$pluginVersion = 0;
            return _mt("<br><span style=\"font-weight: bold;color: red\">使用此功能需要安装并启用 Mirages Plugin (需要 %s 或以上版本)</span>", $versionTag);
        }
        $need = intval($version);
        if (self::$pluginVersion < 0) {
            self::$pluginVersion = 0;
            $plugins = Typecho_Plugin::export();
            $plugins = $plugins['activated'];
            if (is_array($plugins) && array_key_exists('Mirages', $plugins)) {
                self::$pluginVersion = Mirages_Plugin::VERSION;
            }
        }
        $available = self::$pluginVersion >= $need;

        if (!$available) {
            return _mt($templateMessage, $versionTag);
        }
        return "";
    }
    
    static function welcome() {
        $acceptDev = 0;
        if (self::pluginAvailable(100)) {
            $acceptDev = intval(Helper::options()->plugin('Mirages')->acceptDev);
        }
        $root = rtrim(Helper::options()->themeUrl, '/') . '/';
        return '<p style="font-size:16px;">'. _mt('感谢您使用 Mirages'). ' • <a href="https://get233.com/archives/mirages-home.html?v='. self::$version .'" target="_blank">'. _mt('主题帮助文档').'</a> • <a href="https://get233.com/archives/mirages-intro.html?theme_option&v='. self::$version .'#comments" target="_blank">'. _mt('意见或建议').'</a> • <a href="https://get233.com/archives/mirages-update-log-1.html?theme_option&v='. self::$version .'" target="_blank">'. _mt('主题更新日志').'</a></p>'. '<p style="font-size:14px;">'. _mt('版本: '). self::$versionTag .' <a id="mirages_update_link" href="http://wpa.qq.com/msgrd?v=3&uin=278448087&site=qq&menu=yes" target="_blank"><span id="mirages_update_notification"></span></a></p><p style="font-size:14px;">　</p>'. "<script src=\"{$root}static/jquery/2.2.4/jquery.min.js\" type=\"text/javascript\"></script>". '<script type="text/javascript">(function($){$.getJSON("https://api.hran.me/mirages/checkForUpdates?current='. self::$version .'&name='.License::$name.'&pk='.License::$pk.'&acceptDev='.$acceptDev.'&callback=?",null,function(data){if(data.error_no!=1){$("#mirages_update_notification").css("color","#333").html("['. _mt('你可以到这里查看主题的最新版本').']");return}if(data.new_version_available){var message="["+data.update_message+"]";var color=data.color||"#1abc9c";$("#mirages_update_notification").css("color",color).html(message);$("#mirages_update_link").attr("href", data.update_link)}else{$("#mirages_update_notification").css("color","#333").html("['. _mt('当前已为最新版').']")}})})(jQuery)</script>'. <<<EOF

<style type="text/css">
    textarea {
        -webkit-overflow-scrolling: touch;
    }
    .settings-title {
        font-size: 2em;
        border-bottom: 1px #ddd solid;
        padding-top:2em;
    }
    ul.typecho-option.typecho-option-submit {
        position:fixed;
        bottom:0;
        width:100%;
        background:rgba(117,117,117,.5);
        height:50px;
        margin-bottom:0;
        left:0;
        text-align:center;
    }
    @supports (-webkit-backdrop-filter: brightness(150%) blur(30px)) or (backdrop-filter:blur(20px)) {
        ul.typecho-option.typecho-option-submit {
            background:rgba(117,117,117,.3);
            -webkit-backdrop-filter:blur(20px);
            backdrop-filter:blur(20px);
        }
    }
    ul.typecho-option.typecho-option-submit li {
        padding-top: 9px;
    }
    ul.typecho-option.typecho-option-submit li button {
        width:300px;
        max-width:85%;
        background-color:#0c9;
    }
</style>

EOF;
    }

    static function helloWrite() {
        Mirages::init();
        if (!Mirages::$options->themeFieldsLoaded) {
            Mirages::$options->themeFieldsLoaded = true;
            $root = rtrim(Helper::options()->themeUrl, '/') . '/';
            if (Mirages::pluginAvailable(100) && method_exists("Mirages_Plugin", "biaoqingRootPath")) {
                $biaoqingRootPath = Mirages_Plugin::biaoqingRootPath();
            } else {
                $biaoqingRootPath = array();
            }
            return <<<EOF
<style type="text/css">
.typecho-post-area #text {
    -webkit-overflow-scrolling: touch;
}
.typecho-list-table textarea, .typecho-list-table input[type="text"] {
    width: 100%;
    -webkit-overflow-scrolling: touch;
}
.typecho-list-table tbody tr:hover td {
    background-color: transparent !important;
}
.OwO {
    margin-bottom: 5px;
}
.OwO-logo {
    background: #F6F6F3;
}
@media screen and (max-width: 610px) {
    .OwO {
        text-align: right;
    }
}
img.biaoqing, #ds-thread #ds-reset .ds-comment-body img.biaoqing {
    display: inline;
    margin: 0;
    width: auto;
    max-width: 6.25rem;
}
img.biaoqing.paopao, #ds-thread #ds-reset .ds-comment-body img.biaoqing.paopao {
    margin-bottom: -0.3125rem;
    height: 2rem;
}
#ds-thread #ds-reset .ds-comment-body .ds-ctx-content img.biaoqing.paopao {
    margin-bottom: -0.1875rem;
    min-height: 1.5rem;
}
img.biaoqing.newpaopao, #ds-thread #ds-reset .ds-comment-body img.biaoqing.newpaopao {
    margin-bottom: -0.25rem;
    min-height: 1.875rem;
    height: 1em;
}
#ds-thread #ds-reset .ds-comment-body .ds-ctx-content img.biaoqing.newpaopao {
    margin-bottom: -0.1875rem;
    min-height: 1.5rem;
}
img.biaoqing.alu, #ds-thread #ds-reset .ds-comment-body img.biaoqing.alu {
    margin-bottom: -0.3125rem;
    min-height: 2.0625rem;
    height: 1em;
}
#ds-thread #ds-reset .ds-comment-body .ds-ctx-content img.biaoqing.alu {
    margin-bottom: -0.1875rem;
    min-height: 1.5rem;
}
img.biaoqing.custom, #ds-thread #ds-reset .ds-comment-body img.biaoqing.custom {
    margin-bottom: 0;
    min-height: 2.75rem;
    height: 1em;
}
#ds-thread #ds-reset .ds-comment-body .ds-ctx-content img.biaoqing.custom {
    margin-bottom: -0.1875rem;
    min-height: 1.5rem;
}
</style>
<link rel="stylesheet" href="{$root}css/OwO.custom.min.css">
<script src="{$root}static/jquery/2.2.4/jquery.min.js" type="text/javascript"></script>
<script src="{$root}js/OwO.custom.min.js" type="text/javascript"></script>
<script type="text/javascript">
    window['LocalConst'] = {
        BIAOQING_PAOPAO_PATH: '{$biaoqingRootPath['paopao']}',
        BIAOQING_ARU_PATH: '{$biaoqingRootPath['aru']}',
    };

    $(document).ready(function(){
        $('body').addClass('theme-white');
        $('#text').before('<span class="OwO"></span>');
        var owo = new OwO({
            logo: '^_^',
            container: document.getElementsByClassName('OwO')[0],
            target: document.getElementById('text'),
            api: '{$root}js/OwO.json',
            position: 'down',
            style: 'max-width: 100%;',
            maxHeight: '250px'
        });
    });

</script>
EOF;
        }
        return "";
    }
}