<?php if (!defined('__TYPECHO_ROOT_DIR__')) exit;
/**
 * Mirages 主题专用插件
 *
 * @package Mirages
 * @author Hran
 * @version 1.0.4
 * @link https://hran.me
 */
require_once("MiragesPluginUtils.php");
require_once("VersionManager.php");
class Mirages_Plugin implements Typecho_Plugin_Interface {

    //region 插件冲突解决方案系列

    /**
     * 用于插件冲突解决，该方法对应的 Hook 为：
     * `Typecho_Plugin::factory('Widget_Abstract_Contents')->content`
     * 详情请见 @see https://hran.me/archives/typecho-plugin-conflict-solution.html
     * @param $content
     * @param Widget_Abstract_Contents $widget
     * @return mixed
     */
    private static function invokeContentPlugin($content, Widget_Abstract_Contents $widget) {
        $content = $widget->pluginHandle("Mirages_Plugin")->content($content, $widget);
        $content = $widget->pluginHandle("Mirages_Plugin")->content2($content, $widget);

        /*INSERT_PLACEHOLDER_CONTENT*/
        return $content;
    }

    /**
     * 用于插件冲突解决，该方法对应的 Hook 为：
     * `Typecho_Plugin::factory('Widget_Abstract_Contents')->excerpt`
     * 详情请见 @see https://hran.me/archives/typecho-plugin-conflict-solution.html
     * @param $content
     * @param Widget_Abstract_Contents $widget
     * @return mixed
     */
    private static function invokeExcerptPlugin($content, Widget_Abstract_Contents $widget) {
        $content = $widget->pluginHandle("Mirages_Plugin")->excerpt($content, $widget);
        $content = $widget->pluginHandle("Mirages_Plugin")->excerpt2($content, $widget);


        /*INSERT_PLACEHOLDER_EXCERPT*/
        return $content;
    }

    /**
     * 用于插件冲突解决，该方法对应的 Hook 为：
     * `Typecho_Plugin::factory('Widget_Abstract_Contents')->contentEx`
     * 详情请见 @see https://hran.me/archives/typecho-plugin-conflict-solution.html
     * @param $content
     * @param Widget_Abstract_Contents $widget
     * @return mixed
     */
    private static function invokeContentExPlugin($content, Widget_Abstract_Contents $widget) {
        $content = $widget->pluginHandle("Mirages_Plugin")->contentEx($content, $widget);
        $content = $widget->pluginHandle("Mirages_Plugin")->contentEx2($content, $widget);


        /*INSERT_PLACEHOLDER_CONTENT_EX*/
        return $content;
    }

    /**
     * 用于插件冲突解决，该方法对应的 Hook 为：
     * `Typecho_Plugin::factory('Widget_Abstract_Contents')->excerptEx`
     * 详情请见 @see https://hran.me/archives/typecho-plugin-conflict-solution.html
     * @param $content
     * @param Widget_Abstract_Contents $widget
     * @return mixed
     */
    private static function invokeExcerptExPlugin($content, Widget_Abstract_Contents $widget) {
        $content = $widget->pluginHandle("Mirages_Plugin")->excerptEx($content, $widget);
        $content = $widget->pluginHandle("Mirages_Plugin")->excerptEx2($content, $widget);


        /*INSERT_PLACEHOLDER_EXCERPT_EX*/
        return $content;
    }

    /**
     * 用于插件冲突解决，该方法对应的 Hook 为：
     * `Typecho_Plugin::factory('Widget_Contents_Post_Edit')->write`
     * 详情请见 @see https://hran.me/archives/typecho-plugin-conflict-solution.html
     * @param $content
     * @param Widget_Abstract_Contents $widget
     * @return mixed
     */
    private static function invokePostWritePlugin($content, Widget_Abstract_Contents $widget) {
        $content = $widget->pluginHandle("Mirages_Plugin")->writePost($content, $widget);
        $content = $widget->pluginHandle("Mirages_Plugin")->writePost2($content, $widget);


        /*INSERT_PLACEHOLDER_POST_WRITE*/
        return $content;
    }

    /**
     * 用于插件冲突解决，该方法对应的 Hook 为：
     * `Typecho_Plugin::factory('Widget_Contents_Page_Edit')->write`
     * 详情请见 @see https://hran.me/archives/typecho-plugin-conflict-solution.html
     * @param $content
     * @param Widget_Abstract_Contents $widget
     * @return mixed
     */
    private static function invokePageWritePlugin($content, Widget_Abstract_Contents $widget) {
        $content = $widget->pluginHandle("Mirages_Plugin")->writePage($content, $widget);
        $content = $widget->pluginHandle("Mirages_Plugin")->writePage2($content, $widget);


        /*INSERT_PLACEHOLDER_PAGE_WRITE*/
        return $content;
    }
    //endregion

    //region Const
    const KEY_WIDTH = "mirages-width";
    const KEY_HEIGHT = "mirages-height";
    const KEY_CDN_TYPE = "mirages-cdn-type";

    const VERSION_REQUIRED_LAZYLOAD = 170;
    const VERSION_TAG_REQUIRED_LAZYLOAD = "1.7.0";

    const VERSION = 104;
    const VERSION_TAG = "1.0.4";

    const CDN_TYPE_OTHERS = -1;
    const CDN_TYPE_QINIU = 1;
    const CDN_TYPE_UPYUN = 2;
    const CDN_TYPE_LOCAL = 3;
    const CDN_TYPE_ALIYUN_OSS = 4;

    const CDN_NAME_QINIU = 'QINIU';
    const CDN_NAME_UPYUN = 'UPYUN';
    const CDN_NAME_LOCAL = 'LOCAL';
    const CDN_NAME_ALIYUN_OSS = 'ALIOSS';
    //endregion

    //region Fields
    /** @var Typecho_Config */
    private static $pluginOptions = null;
    /** @var Widget_Options */
    private static $themeOptions = null;
    private static $themeVersion = -1;

//    private static $qiniuHosts = array(
//        "clouddn.com",
//        "qiniucdn.com",
//        "qiniudn.com",
//        "qnssl.com",
//        "qbox.me",
//    );

//    private static $upYunHosts = array(
//        "upaiyun.com",
//    );

    private static $cdnHosts = array(
        self::CDN_NAME_QINIU => array(
            "clouddn.com",
            "qiniucdn.com",
            "qiniudn.com",
            "qnssl.com",
            "qbox.me",
        ),
        self::CDN_NAME_UPYUN => array(
            "upaiyun.com",
        ),
        self::CDN_NAME_ALIYUN_OSS => array(
            "aliyuncs.com"
        )
    );

    private static $pluginBaseUrl = null;
    private static $biaoqingRootPath = array();

    private static $lastPostModified = false;
    private static $optionLoaded = false;

    private static $cleanMode = false;
    private static $cleanConfirmMode = false;

    private static $shortcodeTags = array();
    //endregion

    //region 插件基础方法
    /**
     * 激活插件方法,如果激活失败,直接抛出异常
     *
     * @access public
     * @return void
     * @throws Typecho_Plugin_Exception
     */
    public static function activate() {
        $plugins = Typecho_Plugin::export();
        $plugins = $plugins['activated'];

        Typecho_Plugin::factory('Widget_Contents_Post_Edit')->write_99999999 = array("Mirages_Plugin", 'postWrite');
        Typecho_Plugin::factory('Widget_Contents_Page_Edit')->write_99999999 = array("Mirages_Plugin", 'pageWrite');

        Typecho_Plugin::factory('Widget_Abstract_Contents')->content_99999999 = array('Mirages_Plugin', 'content');
        Typecho_Plugin::factory('Widget_Abstract_Contents')->excerpt_99999999 = array('Mirages_Plugin', 'excerpt');

        Typecho_Plugin::factory('Widget_Abstract_Contents')->contentEx_99999999 = array("Mirages_Plugin", 'contentEx');
        Typecho_Plugin::factory('Widget_Abstract_Contents')->excerptEx_99999999 = array("Mirages_Plugin", 'excerptEx');

        if (is_array($plugins) && array_key_exists('ContentHandler', $plugins)) {
            Typecho_Plugin::deactivate("ContentHandler");
            return "检测到 ContentHandler 插件，已将其禁用，原因是功能重复。";
        }
    }

    /**
     * 禁用插件方法,如果禁用失败,直接抛出异常
     *
     * @static
     * @access public
     * @return void
     * @throws Typecho_Plugin_Exception
     */
    public static function deactivate(){
        $plugins = Typecho_Plugin::export();
        $plugins = $plugins['activated'];
        if (is_array($plugins) && array_key_exists('ContentHandler', $plugins)) {
            Typecho_Plugin::deactivate("ContentHandler");
            return "ContentHandler 目前以依赖此插件的方式运行。已同时将 ContentHandler 插件禁用，如需继续使用请重新激活 ContentHandler 插件。";
        }
    }

    /**
     * 获取插件配置面板
     *
     * @access public
     * @param Typecho_Widget_Helper_Form $form 配置面板
     * @return void
     */
    public static function config(Typecho_Widget_Helper_Form $form) {
        
        

        if (isset($_GET['action']) && $_GET['action'] == 'loadAllImageInfo') {
            self::loadAllImageInfo();
        }

        if (isset($_GET['action']) && $_GET['action'] == 'cleanAllImageInfo') {
            self::cleanAllImageInfo();
        }

        if (isset($_GET['action']) && $_GET['action'] == 'requestUpdate') {
            $message = VersionManager::requestUpdate();
            if ($message['status'] == 'success' || (array_key_exists('hideLog', $message) && $message['hideLog'] > 0)) {
                Typecho_Widget::widget('Widget_Notice')->set(_t($message['message']), $message['status']);
                Typecho_Response::getInstance()->goBack();
            }
        }

        if (isset($_GET['action']) && $_GET['action'] == 'deleteOldTheme') {
            $message = self::deleteOldTheme();
            if (!empty($message)) {
                Typecho_Widget::widget('Widget_Notice')->set(_t($message['message']), $message['status']);
                Typecho_Response::getInstance()->goBack();
            }
            return;
        }

        if (self::$themeVersion < 0) {
            self::loadThemeVersion();
        }
//        $versionNotSupportMsg = "";
//        if (self::$themeVersion < self::VERSION_REQUIRED_LAZYLOAD) {
//            $v = self::VERSION_TAG_REQUIRED_LAZYLOAD;
//            $versionNotSupportMsg = "<br><span style=\"font-weight: bold;color: red\">当前主题版本过低，开启/执行此选型需要 Mirages 主题 {$v} 或以上版本，否则图片加载会出现不被预期的问题。</span>";
//        }



        $form->addInput(new Title_Plugin('speedTitle', NULL, NULL, _t('速度优化'), NULL));
        $customQiniuHosts = new Typecho_Widget_Helper_Form_Element_Hidden('customQiniuHosts', NULL, NULL, _t('自定义七牛域名'), _t('配置您在七牛融合 CDN 中配置的加速域名，如果使用的是七牛的默认域名，择不需要写。<br>每行一个，只要写域名即可，不需要写http/https.<br>例如：cdn.example.com'));
        $form->addInput($customQiniuHosts);
        $customUPYunHosts = new Typecho_Widget_Helper_Form_Element_Hidden('customUPYunHosts', NULL, NULL, _t('自定义又拍云存储域名'), _t('配置您在又拍云存储中定义的自定义域名，如果使用的是又拍云提供的默认域名，择不需要写。<br>每行一个，只要写域名即可，不需要写http/https.<br>例如：cdn.example.com'));
        $form->addInput($customUPYunHosts);
        $customCDNHosts = new Typecho_Widget_Helper_Form_Element_Textarea('customCDNHosts', NULL, NULL, _t('自定义 CDN 域名'), _t('配置您的自定义域名使用的云存储服务类型，云存储的默认域名不需要填写。<br>每行配置一个域名，自定义域名只要写域名即可，不需要写http/https.<br>配置方式为: <code>自定义域名 : CDN类型</code><br>例如：cdn.example.com: QINIU<br>目前可以配置的CDN类型有：<br>七牛云存储「QINIU」<br> 又拍云存储「 UPYUN」<br>阿里云 OSS「ALIOSS」'));
        $form->addInput($customCDNHosts);
        $upYunSplitTag = new Typecho_Widget_Helper_Form_Element_Select('upYunSplitTag', array('!'=>_t('!'), '-'=>_t('-'), '_'=>_t('_')), '!', _t('又拍云间隔标识符'), _t('用于分隔图片 URL 和处理信息，可登录又拍云<a href="https://console.upyun.com/services/" target="_blank">控制台</a>，在 「服务」 > 「功能配置」 > 「云处理」 中设置。<br>又拍云的默认间隔标识符为「!」'));
        $form->addInput($upYunSplitTag);


        $form->addInput(new Title_Plugin('biaoqingTitle', NULL, NULL, _t('表情解析'), NULL));
        $biaoqingRootPath = new Typecho_Widget_Helper_Form_Element_Textarea('biaoqingRootPath', NULL, NULL, _t('自定义表情根目录'), _t('<span style="color: red">其实完全可以不用配置</span><br>配置自定义的表情根目录，如果定义了就会使用自定义的路径加载表情，否则会使用<span style="color: red">插件中自带的表情哦</span><br>每行配置一个表情路径，格式为：表情名称 (加英文冒号:) 自定义路径<br>示例：paopao:https://github.com/path/to/paopao/<br>目前可以配置的表情有：「paopao」、「aru」'));
        $form->addInput($biaoqingRootPath);

        $form->addInput(new Title_Plugin('btnTitle', NULL, NULL, _t('操作'), NULL));

        $queryBtn = new Typecho_Widget_Helper_Form_Element_Submit();
        $queryBtn->value(_t('为所有文章获取图片基础信息，请谨慎操作。'));
        $queryBtn->description(_t('<span style="font-weight: bold;color: red">建议在执行此操作前备份数据库。</span><br>要实现图片加载动画功能，需要在图片链接中保存图片基础信息。<br>你可以点击此按钮转换所有的文章。<br>除此之外，你在每次保存文章的时候插件同样会自动获取并保存这些信息。<br>本操作一次最多转换 5 篇文章。'));
        $queryBtn->input->setAttribute('class','btn btn-s btn-warn btn-operate');
        $queryBtn->input->setAttribute('formaction',Typecho_Common::url('/options-plugin.php?config=Mirages&action=loadAllImageInfo',Helper::options()->adminUrl));
        $form->addItem($queryBtn);

        $cleanBtn = new Typecho_Widget_Helper_Form_Element_Submit();
        $cleanBtn->value(_t('<span style="font-weight: 700;margin-right: 0;">清理</span>所有文章获取到的图片基础信息，请谨慎操作。'));
        $cleanBtn->description(_t('<span style="font-weight: bold;color: red">建议在执行此操作前备份数据库。</span><br>清理前面的操作写入的图片基础信息，建议仅在切换至其他主题时清理，当然，不清理也不会有什么影响。<br>所以这是一个适用于强迫症的操作<br>'));
        $cleanBtn->input->setAttribute('class','btn btn-s btn-warn btn-operate');
        $cleanBtn->input->setAttribute('formaction',Typecho_Common::url('/options-plugin.php?config=Mirages&action=cleanAllImageInfo',Helper::options()->adminUrl));
        $form->addItem($cleanBtn);

        $form->addInput(new Title_Plugin('updateTitle', NULL, NULL, _t('在线更新'), _t('并不会在你不知情的情况下进行更新主题，只有在你点击更新操作的时候才会执行更新。<br>你可以在<a href="./options-theme.php" target="_blank">主题外观设置</a>页面查看主题的最新版本及更新信息。')));
        $acceptsDev = new Typecho_Widget_Helper_Form_Element_Radio('acceptDev', array('0'=>_t('是'), '1'=>_t('<span style="color: red; font-weight: 700;">否，我愿意更新到开发版</span>')), '0', _t('仅接受正式版更新'),_t('选择是否接收开发版更新，该选项在保存后才会生效。'));
        $form->addInput($acceptsDev);

        $updateBtn = new Typecho_Widget_Helper_Form_Element_Submit();
        $updateBtn->value(_t('更新主题和插件至最新版本'));
        $updateBtn->description(_t('更新操作可能会耗时1分钟甚至更长时间，这取决于你主机的网络速度和其他硬件条件。<br>在这期间，请不要进行任何操作，否则，可能会导致主题更新失败。<br><strong style="color: red">主题升级后，新版主题默认继承旧版主题的外观设置，如果启用旧版主题，所有主题的外观设置都将丢失！<br>所以，升级主题的过程中(包含升级前和升级后), 请不要在外观设置中启用/切换任何主题，否则当前使用的主题设置将会全部丢失！</strong>'));
        $updateBtn->input->setAttribute('class','btn btn-s btn-warn btn-operate');
        $updateBtn->input->setAttribute('formaction',Typecho_Common::url('/options-plugin.php?config=Mirages&action=requestUpdate',Helper::options()->adminUrl));
        $form->addItem($updateBtn);

        $deleteBtn = new Typecho_Widget_Helper_Form_Element_Submit();
        $deleteBtn->value(_t('删除旧版主题'));
        $deleteBtn->description(_t('在线更新完成后，暂时不会删除旧版本使用的主题。原因是在线更新的新版主题将不再包含你对主题所做的所有增改（除了主题目录下的 /usr 文件夹下的内容）。<br>这样会在主题列表中存在两个 Mirages 主题，你可以在备份后或确认不需要以后，点击这个按钮删除旧版主题。'));
        $deleteBtn->input->setAttribute('class','btn btn-s btn-warn btn-operate');
        $deleteBtn->input->setAttribute('formaction',Typecho_Common::url('/options-plugin.php?config=Mirages&action=deleteOldTheme',Helper::options()->adminUrl));
        $form->addItem($deleteBtn);

        $form->addInput(new Title_Plugin('placeholderTitle', NULL, NULL, '', NULL));
    }

    /**
     * 个人用户的配置面板
     *
     * @access public
     * @param Typecho_Widget_Helper_Form $form
     * @return void
     */
    public static function personalConfig(Typecho_Widget_Helper_Form $form){}
    //endregion

    //region 插件操作响应方法
    private static function loadAllImageInfo() {
        self::loadPluginOptions();

        if (self::$themeVersion < 0) {
            self::loadThemeVersion();
        }

        if (self::$themeVersion < self::VERSION_REQUIRED_LAZYLOAD) {
            Typecho_Widget::widget('Widget_Notice')->set(_t("主题版本过低，请更新至 %s 或以上版本", self::VERSION_TAG_REQUIRED_LAZYLOAD), 'success');
            Typecho_Response::getInstance()->goBack();
            return;
        }

        $db = Typecho_Db::get();

        $count = 0;
        $currentCid = -1;
        $lastTitle = "";

        while (true) {
            $contents = $db->fetchAll($db->select('*')
                ->from('table.contents')
                ->where('cid > ?', $currentCid)
                ->order('cid', Typecho_Db::SORT_ASC)
                ->limit(10));

            if (empty($contents)) {
                break;
            }
            foreach ($contents as $content) {
                self::$lastPostModified = false;
                $text = $content['text'];
                $lastTitle = $content['title'];
                if (empty($text)) {
                    continue;
                }
                $cid = $content['cid'];

                if (!is_numeric($cid)) {
                    continue;
                }
                $currentCid = $cid;
                self::$cleanMode = false;
                self::$cleanConfirmMode = false;
                if (MiragesPluginUtils::startsWith($text, '<!--markdown-->')) {
                    $parsedContent = self::handleMarkdown($text, array("Mirages_Plugin", '_doParseContentBeforePublish'));
                } else {
                    $parsedContent = self::handleHtml('<!--html-->'.$text, array("Mirages_Plugin", "_doParseContentBeforePublish"));
                }

                if (self::validateContentAfterParsed($text, $parsedContent)) {
                    if (MiragesPluginUtils::startsWith($parsedContent, '<!--html-->')) {
                        $parsedContent = substr($parsedContent, 11);
                    }
                } else {
                    $message = "文章《{$lastTitle}》处理失败";
                    Typecho_Widget::widget('Widget_Notice')->set(_t($message), 'error');
                    Typecho_Response::getInstance()->goBack();
                    return;
                }

                if ($parsedContent === $content['text']) {
                    continue;
                }

                if (!self::$lastPostModified) {
                    continue;
                }

                $db->query($db->update('table.contents')
                    ->rows(array(
                        'text' => $parsedContent,
                    ))
                    ->where('cid = ?', $content['cid']));
                $count++;
                if ($count >= 5) {
                    break;
                }
            }
            if ($count >= 5) {
                break;
            }
        }

        if ($count == 0) {
            $message = "操作成功！文章已全部处理完毕！";
        } else {
            $message = "操作成功！本次处理了 {$count} 篇文章。最后一篇文章为《{$lastTitle}》";
        }

        Typecho_Widget::widget('Widget_Notice')->set(_t($message), 'success');
        Typecho_Response::getInstance()->goBack();
    }

    private static function cleanAllImageInfo() {
        self::loadPluginOptions();

        $db = Typecho_Db::get();

        $count = 0;
        $currentCid = -1;
        $lastTitle = "";

        while (true) {
            $contents = $db->fetchAll($db->select('*')
                ->from('table.contents')
                ->where('cid > ?', $currentCid)
                ->order('cid', Typecho_Db::SORT_ASC)
                ->limit(10));

            if (empty($contents)) {
                break;
            }
            foreach ($contents as $content) {
                self::$lastPostModified = false;
                $text = $content['text'];
                $lastTitle = $content['title'];
                if (empty($text)) {
                    continue;
                }
                $cid = $content['cid'];

                if (!is_numeric($cid)) {
                    continue;
                }
                $currentCid = $cid;
                self::$cleanMode = true;
                self::$cleanConfirmMode = true;
                if (MiragesPluginUtils::startsWith($text, '<!--markdown-->')) {
                    $parsedContent = self::handleMarkdown($text, array("Mirages_Plugin", '_doParseContentBeforePublish'));
                } else {
                    $parsedContent = self::handleHtml('<!--html-->'.$text, array("Mirages_Plugin", "_doParseContentBeforePublish"));
                }

                if (self::validateContentAfterParsed($text, $parsedContent)) {
                    if (MiragesPluginUtils::startsWith($parsedContent, '<!--html-->')) {
                        $parsedContent = substr($parsedContent, 11);
                    }
                } else {
                    $message = "文章《{$lastTitle}》处理失败";
                    Typecho_Widget::widget('Widget_Notice')->set(_t($message), 'error');
                    Typecho_Response::getInstance()->goBack();
                    return;
                }

                if ($parsedContent === $content['text']) {
                    continue;
                }

                if (!self::$lastPostModified) {
                    continue;
                }

                $db->query($db->update('table.contents')
                    ->rows(array(
                        'text' => $parsedContent,
                    ))
                    ->where('cid = ?', $content['cid']));
                $count++;
            }
        }

        if ($count == 0) {
            $message = "操作成功！文章已全部清理完毕！";
        } else {
            $message = "操作成功！文章已全部清理完毕！本次清理了 {$count} 篇文章。最后一篇文章为《{$lastTitle}》";
        }

        Typecho_Widget::widget('Widget_Notice')->set(_t($message), 'success');
        Typecho_Response::getInstance()->goBack();
    }


    private static function deleteOldTheme() {
        self::loadPluginOptions();

        $themeOld = MiragesPluginUtils::themesDir() . "Mirages-Old";

        if (file_exists($themeOld)) {
            MiragesPluginUtils::deleteDirectory($themeOld);
        }
        return array(
            'status' => 'success',
            'message' => '删除成功',
        );
    }

    //endregion

    //region 插件注册 invoke 方法
    public static function postWrite($content, Widget_Abstract_Contents $widget) {
        $content = self::beforePublish($content, $widget);
        $content = self::invokePostWritePlugin($content, $widget);
        return $content;
    }

    public static function pageWrite($content, Widget_Abstract_Contents $widget) {
        $content = self::beforePublish($content, $widget);
        $content = self::invokePageWritePlugin($content, $widget);
        return $content;
    }

    public static function content($content, Widget_Abstract_Contents $widget) {
        $content = self::parseContent($content, $widget);
        $content = self::invokeContentPlugin($content, $widget);
        return $content;
    }
    public static function excerpt($content, Widget_Abstract_Contents $widget) {
        $content = self::parseContent($content, $widget);
        $content = self::invokeExcerptPlugin($content, $widget);
        return $content;
    }

    public static function contentEx($content, Widget_Abstract_Contents $widget) {
        $content = self::beforeShown($content, $widget);
        $content = self::invokeContentExPlugin($content, $widget);
        return $content;
    }
    public static function excerptEx($content, Widget_Abstract_Contents $widget) {
        $content = self::beforeShown($content, $widget);
        $content = self::invokeExcerptExPlugin($content, $widget);
        return $content;
    }
    //endregion

    //region 插件逻辑处理入口方法
    /**
     * 插件方法
     * @param $content
     * @param Widget_Abstract_Contents $widget
     * @return array
     */
    private static function beforePublish($content, Widget_Abstract_Contents $widget) {
        self::loadPluginOptions();

        if (self::lazyloadEnabled()) {
            $_contentText = $content['text'];
            self::$cleanMode = false;
            self::$cleanConfirmMode = false;
            if (MiragesPluginUtils::startsWith($_contentText, '<!--markdown-->')) {
                $parsedContent = self::handleMarkdown($_contentText, array("Mirages_Plugin", '_doParseContentBeforePublish'));
            } else {
                $parsedContent = self::handleHtml('<!--html-->'.$_contentText, array("Mirages_Plugin", "_doParseContentBeforePublish"));
            }
            if (self::validateContentAfterParsed($_contentText, $parsedContent)) {
                if (MiragesPluginUtils::startsWith($parsedContent, '<!--html-->')) {
                    $parsedContent = substr($parsedContent, 11);
                }
            } else {
                // rollback
                $parsedContent = $_contentText;
            }
            $content['text'] = $parsedContent;
        }
        return $content;
    }

    private static function parseContent($text, Widget_Abstract_Contents $widget) {
        self::loadPluginOptions();

        if ($widget->isMarkdown) {
            $text = self::handleMarkdownSyntaxCompatibility($text);
            $content = $widget->markdown($text);
        } else {
            $content = $widget->autoP($text);
        }
        return $content;
    }

    private static function beforeShown($content, Widget_Abstract_Contents $widget) {
        self::loadPluginOptions();

        $content = self::handleHtml($content, array("Mirages_Plugin", '_doParseContentBeforeShow'));

        $content = self::_doUnEscapeTexBlock($content);

        return $content;
    }
    //endregion

    //region 插件逻辑处理实际执行回调方法

    private static function validateContentAfterParsed($original, $parsed) {
        if (MiragesPluginUtils::startsWith($original, '<!--markdown-->')) {
            if (!MiragesPluginUtils::startsWith($parsed, '<!--markdown-->')) {
                return false;
            }
        } else {
            if (!MiragesPluginUtils::startsWith($parsed, '<!--html-->')) {
                return false;
            }
        }
        return true;
    }

    private static function _doParseContentBeforePublish($content) {
        $_content = $content;
        try {
            // 处理 ![alt](image_url)
            $content = preg_replace_callback('/!\[([^\]]*?)\]\(([^\)]+?)\)/sm', array('Mirages_Plugin', '_doHandleImageWithAltBeforePublish'), $content);

            // 处理 [index]: image_url
            $content = preg_replace_callback('/\[([\d\s]+)\]\s*:\s*(((https:|http:|ftp:|rtsp:|mms:){0,1}\/\/)[^\s]+)/sm', array('Mirages_Plugin', '_doHandleImageWithIndexBeforePublish'), $content);

            // 处理 Image 标签
            $content = preg_replace_callback('/\<img\s*([^\>]+?)\s*\/{0,1}\>/sm', array('Mirages_Plugin', '_doHandleImageTagBeforePublish'), $content);

            $error = error_get_last();

            if (!empty($error) && array_key_exists('message', $error) && MiragesPluginUtils::startsWith($error['message'], 'preg_replace_callback')) {
                var_dump($error);
                return $_content;
            }
        } catch (Exception $e) {
            return $_content;
        }

        return $content;
    }

    private static function _doHandleImageWithAltBeforePublish($matches) {
        $title = $matches[1];
        $url = $matches[2];

        $url = self::addMiragesWidthAndSize($url);

        return "![{$title}]({$url})";
    }

    private static function _doHandleImageWithIndexBeforePublish($matches){
        $index = $matches[1];
        $url = $matches[2];

        $url = self::addMiragesWidthAndSize($url);

        return "[{$index}]: {$url}";
    }

    private static function _doHandleImageTagBeforePublish($matches) {
        $attrs = $matches[1];

        $attrs = MiragesPluginUtils::parseHTMLTagAttribute($attrs);
        if (!empty($attrs['src'])) {

            $url = MiragesPluginUtils::trimAttributeValue($attrs['src']);
            $url = self::addMiragesWidthAndSize($url);

            $attrs['src'] = $url;
        }

        $attrs = MiragesPluginUtils::buildHTMLTagAttribute($attrs);

        return "<img{$attrs}>";
    }

    private static function _doParseContentBeforeShow($content) {
        // 处理 Image 标签
        $content = preg_replace_callback('/\<img\s*([^\>]+?)\s*\/{0,1}\>/sm', array('Mirages_Plugin', '_doHandleImageTagBeforeShow'), $content);

        $content = self::doParseBiaoqing($content);

        if ((!empty(self::$themeOptions->markdownExtend) && in_array('enablePhonetic', self::$themeOptions->markdownExtend))) {
            $content = self::_renderPhonetic($content);
        }
        if ((!empty(self::$themeOptions->markdownExtend) && in_array('enableDeleteLine', self::$themeOptions->markdownExtend))) {
            $content = self::_renderDeleteTag($content);
        }
        if ((!empty(self::$themeOptions->markdownExtend) && in_array('enableHighlightText', self::$themeOptions->markdownExtend))) {
            $content = self::_renderHighlight($content);
        }
        if ((!empty(self::$themeOptions->markdownExtend) && in_array('enableCheckbox', self::$themeOptions->markdownExtend))) {
            $content = self::_renderCheckbox($content);
        }

        $content = self::_escapeCharacter($content);
        $content = self::_renderCards($content);
        $content = self::parseShortcode($content);

        return $content;
    }
    private static function _doHandleImageTagBeforeShow($matches) {
        $attrs = $matches[1];

        $attrs = MiragesPluginUtils::parseHTMLTagAttribute($attrs);
        if (array_key_exists('src', $attrs) && !MiragesPluginUtils::emptyAttribute($attrs['src'])) {
            $url = MiragesPluginUtils::trimAttributeValue($attrs['src']);
        } elseif (array_key_exists('data-src', $attrs) && !MiragesPluginUtils::emptyAttribute($attrs['data-src'])) {
            $url = MiragesPluginUtils::trimAttributeValue($attrs['data-src']);
        }
        if (!empty($url)) {
            $url = self::_replaceIMGWithCDNDomain($url);
            $part = parse_url($url);
            $lazyLoaded = false;
            if (array_key_exists('fragment', $part) && !empty($part['fragment'])) {
                $fragment = $part['fragment'];
                $fragment = str_replace("&amp;", "&", $fragment);
                $fragment = str_replace("#", "&", $fragment);
                $fragment = MiragesPluginUtils::httpParseQuery($fragment);
                if (self::lazyloadEnabled() && array_key_exists(self::KEY_WIDTH, $fragment) && array_key_exists(self::KEY_HEIGHT, $fragment)) {
                    $width = intval($fragment[self::KEY_WIDTH]);
                    $height = intval($fragment[self::KEY_HEIGHT]);
                    if ($width > 0 && $height > 0) {

                        $fragmentAttrs = array();

                        foreach ($fragment as $key => $value) {
                            if (!empty($key) && !empty($value)) {
                                $fragmentAttrs['data-'.$key] = $value;
                            }
                        }
                        $fragmentAttrs['style'] = "width: {$width}px;";

                        unset($part['fragment']);
                        $url = MiragesPluginUtils::httpBuildUrl($part);

                        $attrs['data-src'] = $url;
                        if (array_key_exists(self::KEY_CDN_TYPE, $fragment)) {
                            $cdnType = $fragment[self::KEY_CDN_TYPE];
                        } else {
                            $cdnType = self::getCdnType($url);
                        }

                        $attrs['class'] = "img-small";
                        $attrs['no-zoom'] = "true";
                        $attrs['src'] = self::getThumbnailByCdnType($url, $cdnType);

                        $paddingBottom = round($height * 100.0 / $width, 2) . '%';

                        $attrs = MiragesPluginUtils::buildHTMLTagAttribute($attrs);
                        $fragmentAttrs = MiragesPluginUtils::buildHTMLTagAttribute($fragmentAttrs);

                        $replace = <<<EOF
    <section class="lazy-load" {$fragmentAttrs}>
        <div class="placeholder" style="padding-bottom: {$paddingBottom};"></div>
        <div class="progressiveMedia">
            <img{$attrs} onload="javascript:this.classList.add('loaded');">
        </div>
    </section>
EOF;
                        $lazyLoaded = true;
                    }
                } else {
                    foreach ($fragment as $key => $value) {
                        if (!empty($key) && !empty($value)) {
                            $attrs['data-'.$key] = $value;
                        }
                    }
                }
            }

            if(!$lazyLoaded && (!empty(self::$themeOptions->qiniuOptions) && in_array('qiniuOptimize', self::$themeOptions->qiniuOptions))) {
                unset($part['fragment']);
                unset($part['query']);
                $url = MiragesPluginUtils::httpBuildUrl($part);
                $attrs['data-'.self::KEY_CDN_TYPE] = self::getCdnType($part);
                $attrs['data-src'] = $url;
                unset($attrs['src']);
            }

        }

        if (empty($replace)) {
            $attrs = MiragesPluginUtils::buildHTMLTagAttribute($attrs);
            $replace = "<img{$attrs}>";
        }

        return $replace;

    }


    /**
     * 增强 Markdown 语法兼容性
     * 为了提升后续导出时 Markdown 语法与其他应用的兼容性，这里仅在解析 Markdown 前做处理，
     * 不会更改数据库中保存的原文。
     *
     * 包含：
     *      代码块解析：highlight.js 中代码块定义语言时不能包含特殊字符
     *      MathJax 字符转义的问题。
     * @param $markdown
     * @return mixed
     */
    private static function handleMarkdownSyntaxCompatibility($markdown) {
        $markdown = str_replace("```objective-c", "```objectivec", $markdown);
        $markdown = str_replace("```c++", "```cpp", $markdown);
        $markdown = str_replace("```c#", "```csharp", $markdown);
        $markdown = str_replace("```f#", "```fsharp", $markdown);
        $markdown = str_replace("```F#", "```fsharp", $markdown);

        $markdown = self::escapeTexBlock($markdown);

        return $markdown;
    }

    private static function escapeTexBlock($markdown) {

        if (!(!empty(self::$themeOptions->texOptions) && in_array('showJax', self::$themeOptions->texOptions))) {
            return $markdown;
        }

        $markdown = preg_replace_callback('{
				(?:\n|\r|\A)
				(
					\s*\$\$
				)
				
				[ ]?(\w+)?(?:,[ ]?(\d+))?[ ]* (\n|\r)+  #Whitespace and newline following marker.
				
				# 3: Content
				(
					(?>
						(?!\1 [ ]* (\n|\r))	# Not a closing marker.
						.*(\n|\r)+
					)+
				)
				
				# Closing marker.
				\1 [ ]* (\n|\r)+
			}xm', array('Mirages_Plugin', '_escapeTexBlockCallback'), $markdown);

        $markdown = preg_replace_callback('{
				(?:\n|\r|\A)
				([ ]*)\\\[
				
				[ ]?(\w+)?(?:,[ ]?(\d+))?[ ]* (\n|\r)+  #Whitespace and newline following marker.
				
				# 3: Content
				(
					(?>
						(?!\1 [ ]* (\n|\r))	# Not a closing marker.
						.*(\n|\r)+
					)+
				)
				
				# Closing marker.
				\1\\\] [ ]* (\n|\r)+
			}xm', array('Mirages_Plugin', '_escapeTexBlockCallback'), $markdown);

        $markdown = preg_replace_callback('/\$\$[^\r\n]+?\$\$/i', array('Mirages_Plugin', '_escapeTexBlockCallback'), $markdown);
        $markdown = preg_replace_callback('/\\\([^\r\n]+?\\\)/i', array('Mirages_Plugin', '_escapeTexBlockCallback'), $markdown);
        $markdown = preg_replace_callback('/\\\[[^\r\n]+?\\\]/i', array('Mirages_Plugin', '_escapeTexBlockCallback'), $markdown);

        if (!empty(self::$themeOptions->texOptions) && in_array('useDollarForInline', self::$themeOptions->texOptions)) {
            $markdown = preg_replace_callback('/\$[^\r\n\$]+?\$/i', array('Mirages_Plugin', '_escapeTexBlockCallback'), $markdown);
        }
        return $markdown;
    }

    private static function _escapeTexBlockCallback($matches) {
        $tex = $matches[0];
        $tex = self::_doEscapeTexBlock($tex);
        return $tex;
    }

    private static function _doEscapeTexBlock($tex) {
        $tex = str_replace(" ", "@@PH@SPACE@MIRAGES@@", $tex);
        $tex = str_replace("\\", "@@PH@BACK@SLASH@MIRAGES@@", $tex);
        $tex = str_replace("$", "@@PH@DOLLAR@MIRAGES@@", $tex);
        $tex = str_replace("_", "@@PH@UNDERLINE@MIRAGES@@", $tex);
        $tex = str_replace("[", "@@PH@LEFT@SQUARE@BRACKET@MIRAGES@@", $tex);
        $tex = str_replace("]", "@@PH@RIGHT@SQUARE@BRACKET@MIRAGES@@", $tex);
        return $tex;
    }

    private static function _doUnEscapeTexBlock($tex) {
        $tex = str_replace("@@PH@SPACE@MIRAGES@@", " ", $tex);
        $tex = str_replace("@@PH@BACK@SLASH@MIRAGES@@", "\\", $tex);
        $tex = str_replace("@@PH@DOLLAR@MIRAGES@@", "$", $tex);
        $tex = str_replace("@@PH@UNDERLINE@MIRAGES@@", "_", $tex);
        $tex = str_replace("@@PH@LEFT@SQUARE@BRACKET@MIRAGES@@", "[", $tex);
        $tex = str_replace("@@PH@RIGHT@SQUARE@BRACKET@MIRAGES@@", "]", $tex);
        return $tex;
    }

    private static function _renderPhonetic($content) {
        $content = preg_replace('/\{\{\s*([^\:]+?)\s*\:\s*([^}]+?)\s*\}\}/is',
            "<ruby>$1<rp> (</rp><rt>$2</rt><rp>) </rp></ruby>", $content);
        return $content;
    }

    private static function _renderDeleteTag($content) {
        $content = preg_replace('/\~\~(.+?)\~\~/i', "<del>$1</del>", $content);
        return $content;
    }

    private static function _renderHighlight($content) {
        $content = preg_replace('/\=\=(.+?)\=\=/i', "<span class=\"highlight-text\">$1</span>", $content);
        return $content;
    }

    private static function _renderCheckbox($content) {
        return preg_replace_callback('/<li>\s*\[(\s|x)\]\s*([^<>]+)<\/li>/i', function ($match) {
            $checked = $match[1];
            $text = $match[2];
            $html = '<li class="task-list-item"><input type="checkbox"';
            if ($checked == 'x') {
                $html .= " checked";
            }
            $html .= ' onclick="return false;">';
            if (preg_match('/^[A-Za-z0-9`~\$%\^&\*\-=\+\\\|\/!;:,\.\?\'\"\(\)\[\]\{\}]{1}.*/i', $text)) {
                $html .= '<span class="display-none">&nbsp;</span>';
            }
            $html .= '<span class="task-list-item-text">';
            $html .= $text;
            $html .= '</span>';
            if (preg_match('/.*[A-Za-z0-9`~\$%\^&\*\-=\+\\\|\/!;:,\.\?\'\"\(\)\[\]\{\}]{1}$/i', $text)) {
                $html .= '<span class="display-none">&nbsp;</span>';
            }
            $html .= '</li>';
            return $html;
        }, $content);
    }

    private static function _escapeCharacter($content) {
        $content = str_replace('\~', '~', $content);
        $content = str_replace('\=', '=', $content);
        $content = str_replace('\$', '<span>$</span>', $content);
        return $content;
    }

    private static function _replaceIMGWithCDNDomain($url) {
        if (!(self::$themeOptions->cdnDomain__hasValue && self::$themeOptions->devMode__isFalse)) {
            return $url;
        }
        return preg_replace('/^'.preg_quote(rtrim(self::$themeOptions->siteUrl, '/'), '/').'/', rtrim(self::$themeOptions->cdnDomain, '/'), $url, 1);
    }

    private static function _renderCards($content) {
        $currentGroupId = 0;
        $lastFindIndex = 0;
        $lastFindLength = 0;
        $linkGroup = array();
        $linkGroupStartIndex = array();
        $linkGroupEndIndex = array();
        $first = true;

        $totalCount = preg_match_all('/(<p>)*<a\s+href=\"([^\"]+?)\"[^<>]*>([^<>]+?)<\/a>\+\(<a\s+href=\"([^\"]+?)\">([^<>]+?)<\/a>\)(<\/p>)*(<\s*br\s*\/\s*>)*(<\s*\/\s*br\s*>)*/ixs', $content, $matches);

        if ($totalCount <= 0) {
            $totalCount = preg_match_all('/(<p>)*<a\s+href=\"([^\"]+?)\"[^<>]*>([^<>]+?)<\/a>\+\(<a\s+href=\"([^\"]+?)\)\">([^<>]+?)\)<\/a>(<\/p>)*(<\s*br\s*\/\s*>)*(<\s*\/\s*br\s*>)*/ixs', $content, $matches);
        }

        if ($totalCount <= 0) {
            $totalCount = preg_match_all('/(<p>)*<a\s+href=\"([^\"]+?)\"[^<>]*>([^<>]+?)<\/a>\+\(([^<>]+?)\)(<\/p>)*(<\s*br\s*\/\s*>)*(<\s*\/\s*br\s*>)*/ixs', $content, $matches);
        }

        for ($i = 0; $i < $totalCount; $i++) {
            if ($first) {
                $first = false;
                $useNewGroup = true;
                $currentFindIndex = strpos($content, $matches[0][$i]);
                $currentFindLength = strlen($matches[0][$i]);
            } else {
                $lastEndIndex = $lastFindIndex + $lastFindLength;
                $currentFindIndex = strpos($content, $matches[0][$i], $lastEndIndex - 1);
                $currentFindLength = strlen($matches[0][$i]);
                if ($currentFindIndex - $lastEndIndex >= 0) {
                    $splitContent = substr($content, $lastEndIndex, $currentFindIndex - $lastEndIndex);
                    if (strlen($splitContent) > 0 && preg_match('/\w+/xs', $splitContent)) {
                        $trimSplitContent = preg_replace('/<\s*br\s*\/\s*>/ixs', '', $splitContent);
                        $trimSplitContent = preg_replace('/<\s*\/\s*br\s*>/ixs', '', $trimSplitContent);
                        $trimSplitContent = preg_replace('/<\s*br\s*>/ixs', '', $trimSplitContent);
                        if (strlen($trimSplitContent) > 0 && preg_match('/\w+/xs', $trimSplitContent)) {
                            $useNewGroup = true;
                        } else {
                            $useNewGroup = false;
                        }
                    } else {
                        $useNewGroup = false;
                    }
                } else {
                    $useNewGroup = false;
                }
            }

            if ($useNewGroup) {
                $currentGroupId ++;
            }
            if (!isset($linkGroup[$currentGroupId])) {
                $linkGroup[$currentGroupId] = array();
            }
            if ($useNewGroup) {
                $linkGroupStartIndex[$currentGroupId] = $currentFindIndex;
            }
            $linkGroupEndIndex[$currentGroupId] = $currentFindIndex + $currentFindLength;
            $match = array();
            $match[2] = $matches[2][$i];
            $match[3] = $matches[3][$i];
            $match[4] = $matches[4][$i];
            $linkGroup[$currentGroupId][] = $match;
            $lastFindIndex = $currentFindIndex;
            $lastFindLength = $currentFindLength;
        }

        $output = "";
        for ($i = 1; $i <= $currentGroupId; $i++) {
            $start = $linkGroupStartIndex[$i];

            if ($i > 1){
                $lastId = $i - 1;
                $lastEnd = $linkGroupEndIndex[$lastId];
                $output .= substr($content, $lastEnd, $start - $lastEnd);
            } else {
                $output .= substr($content, 0, $start);
            }
            $matches = $linkGroup[$i];
            $linkGroupHtml = "<div class=\"link-box\">\n";

            foreach ($matches as $match) {
                $linkGroupHtml .= "<a href=\"{$match[2]}\" target=\"_blank\" class=\"no-underline\">";
                $linkGroupHtml .= "<div class=\"thumb\">";
                $linkGroupHtml .= "<img width=\"200\" height=\"200\" src=\"{$match[4]}\" alt=\"{$match[3]}\"></div>";
                $linkGroupHtml .= "<div class=\"content\">";
                $linkGroupHtml .= "<div class=\"title\"><h3>{$match[3]}</h3></div>";
                $linkGroupHtml .= "</div></a>\n";
            }
            $linkGroupHtml .= '</div>';
            $output .= $linkGroupHtml;
        }

        if ($currentGroupId < 1) {
            return $content;
        }

        $output .= substr($content, $linkGroupEndIndex[$currentGroupId]);
        return $output;
    }

    //endregion

    //region Shortcode 解析

    private static function initShortcodeTags() {
        self::$shortcodeTags['comment'] =
        self::$shortcodeTags['x'] = function ($content, $params, $tag) {
            if ($content == null) {
                return FALSE;
            }
            return '';
        };

        self::$shortcodeTags['html'] = function ($content, $params, $tag) {
            $html = str_replace("<br>", "\n", $content);
            $html = htmlspecialchars_decode($html);
            return $html;
        };

        self::$shortcodeTags['button'] = function ($content, $params, $tag) {
            if (array_key_exists('href', $params)) {
                $href = $params['href'];
            } elseif (array_key_exists('link', $params)) {
                $href = $params['link'];
            } else {
                return FALSE;
            }
            if (empty($content) && array_key_exists('title', $params)) {
                $content = $params['title'];
            }
            return "<a href=\"{$href}\" target=\"_blank\" class=\"btn btn-primary\">{$content}</a>";
        };

    }

    private static function parseShortcode($markdown) {
        self::initShortcodeTags();

        if (false === strpos( $markdown, '[' ) ) {
            return $markdown;
        }
        if (empty(self::$shortcodeTags) || !is_array(self::$shortcodeTags)) {
            return $markdown;
        }

        $pattern = self::get_shortcode_regex();
        $markdown = preg_replace_callback("/$pattern/ixm", array('Mirages_Plugin', '_parseShortcodeTag'), $markdown);

        return $markdown;
    }

    private static function _parseShortcodeTag($m) {
        // allow [[foo]] syntax for escaping a tag
        if ($m[1] == '[' && $m[6] == ']') {
            return substr($m[0], 1, -1);
        }

        $tag  = $m[2];
        $attr = self::shortcode_parse_atts($m[3]);
        if (!(array_key_exists(strtolower($tag), self::$shortcodeTags) && is_callable(self::$shortcodeTags[strtolower($tag)]))) {
            return $m[0];
        }

        $content = isset($m[5]) ? $m[5] : null;

        $output = call_user_func(self::$shortcodeTags[strtolower($tag)], $content, $attr, $tag);
        if ($output === FALSE) {
            return $m[0];
        }

        return $m[1] . $output . $m[6];
    }

    private static function get_shortcode_regex($tagnames = null) {
        if (empty($tagnames)) {
            $tagnames = array_keys(self::$shortcodeTags);
        }
        $tagregexp = join( '|', array_map( 'preg_quote', $tagnames ) );
        // WARNING! Do not change this regex without changing do_shortcode_tag() and strip_shortcode_tag()
        // Also, see shortcode_unautop() and shortcode.js.
        // phpcs:disable Squiz.Strings.ConcatenationSpacing.PaddingFound -- don't remove regex indentation
        return
            '\\['                                // Opening bracket
            . '(\\[?)'                           // 1: Optional second opening bracket for escaping shortcodes: [[tag]]
            . "($tagregexp)"                     // 2: Shortcode name
            . '(?![\\w-])'                       // Not followed by word character or hyphen
            . '('                                // 3: Unroll the loop: Inside the opening shortcode tag
            .     '[^\\]\\/]*'                   // Not a closing bracket or forward slash
            .     '(?:'
            .         '\\/(?!\\])'               // A forward slash not followed by a closing bracket
            .         '[^\\]\\/]*'               // Not a closing bracket or forward slash
            .     ')*?'
            . ')'
            . '(?:'
            .     '(\\/)'                        // 4: Self closing tag ...
            .     '\\]'                          // ... and closing bracket
            . '|'
            .     '\\]'                          // Closing bracket
            .     '(?:'
            .         '('                        // 5: Unroll the loop: Optionally, anything between the opening and closing shortcode tags
            .             '[^\\[]*+'             // Not an opening bracket
            .             '(?:'
            .                 '\\[(?!\\/\\2\\])' // An opening bracket not followed by the closing shortcode tag
            .                 '[^\\[]*+'         // Not an opening bracket
            .             ')*+'
            .         ')'
            .         '\\[\\/\\2\\]'             // Closing shortcode tag
            .     ')?'
            . ')'
            . '(\\]?)';                          // 6: Optional second closing brocket for escaping shortcodes: [[tag]]
        // phpcs:enable
    }

    private static function get_shortcode_atts_regex() {
        return '/([\w-]+)\s*=\s*"([^"]*)"(?:\s|$)|([\w-]+)\s*=\s*\'([^\']*)\'(?:\s|$)|([\w-]+)\s*=\s*([^\s\'"]+)(?:\s|$)|"([^"]*)"(?:\s|$)|\'([^\']*)\'(?:\s|$)|(\S+)(?:\s|$)/';
    }

    private static function shortcode_parse_atts($text) {
        $atts    = array();
        $pattern = self::get_shortcode_atts_regex();
        $text    = preg_replace( "/[\x{00a0}\x{200b}]+/u", ' ', $text );
        if ( preg_match_all( $pattern, $text, $match, PREG_SET_ORDER ) ) {
            foreach ( $match as $m ) {
                if ( ! empty( $m[1] ) ) {
                    $atts[ strtolower( $m[1] ) ] = stripcslashes( $m[2] );
                } elseif ( ! empty( $m[3] ) ) {
                    $atts[ strtolower( $m[3] ) ] = stripcslashes( $m[4] );
                } elseif ( ! empty( $m[5] ) ) {
                    $atts[ strtolower( $m[5] ) ] = stripcslashes( $m[6] );
                } elseif ( isset( $m[7] ) && strlen( $m[7] ) ) {
                    $atts[] = stripcslashes( $m[7] );
                } elseif ( isset( $m[8] ) && strlen( $m[8] ) ) {
                    $atts[] = stripcslashes( $m[8] );
                } elseif ( isset( $m[9] ) ) {
                    $atts[] = stripcslashes( $m[9] );
                }
            }
            // Reject any unclosed HTML elements
            foreach ( $atts as &$value ) {
                if ( false !== strpos( $value, '<' ) ) {
                    if ( 1 !== preg_match( '/^[^<]*+(?:<[^>]*+>[^<]*+)*+$/', $value ) ) {
                        $value = '';
                    }
                }
            }
        } else {
            $atts = ltrim( $text );
        }
        return $atts;
    }

    //endregion

    //region 云存储优化方法
    /**
     * 检查 host 类型，目前可用的值有 七牛、又拍、其他
     * @param $host
     * @return int
     */
    public static function getCdnType($host) {
        self::loadPluginOptions();
        if (is_string($host) && !is_array($host)) {
            $host = parse_url($host);
            if (array_key_exists('host', $host)) {
                $host = $host['host'];
            } else {
                return self::CDN_TYPE_OTHERS;
            }
        } elseif (is_array($host)) {
            if (array_key_exists('host', $host)) {
                $host = $host['host'];
            } else {
                return self::CDN_TYPE_OTHERS;
            }
        }
        // check if qiniu cdn
        foreach (self::$cdnHosts[self::CDN_NAME_QINIU] as $qiniuHost) {
            if (empty($qiniuHost)) {
                continue;
            }
            if (MiragesPluginUtils::endsWith($host, $qiniuHost)) {
                return self::CDN_TYPE_QINIU;
            }
        }

        // check if qiniu cdn
        foreach (self::$cdnHosts[self::CDN_NAME_UPYUN] as $upYunHost) {
            if (empty($upYunHost)) {
                continue;
            }
            if (MiragesPluginUtils::endsWith($host, $upYunHost)) {
                return self::CDN_TYPE_UPYUN;
            }
        }

        // check if aliyun oss
        foreach (self::$cdnHosts[self::CDN_NAME_ALIYUN_OSS] as $aliyunOss) {
            if (empty($aliyunOss)) {
                continue;
            }
            if (MiragesPluginUtils::endsWith($host, $aliyunOss)) {
                return self::CDN_TYPE_ALIYUN_OSS;
            }
        }
        return self::CDN_TYPE_OTHERS;
    }

    /**
     * 为 URL 添加图片宽高信息
     * @param $url
     * @return string
     */
    private static function addMiragesWidthAndSize($url) {
        $part = parse_url($url);

        // 清理模式
        if (self::$cleanMode === true && self::$cleanConfirmMode === true) {
            if (array_key_exists('fragment', $part) && !empty($part['fragment'])) {
                $fragment = $part['fragment'];
                $fragment = str_replace("#", "&", $fragment);
                $fragment = MiragesPluginUtils::httpParseQuery($fragment);

                unset($fragment[self::KEY_WIDTH]);
                unset($fragment[self::KEY_HEIGHT]);
                unset($fragment[self::KEY_CDN_TYPE]);

                if (empty($fragment)) {
                    unset($part['fragment']);
                } else {
                    $part['fragment'] = http_build_query($fragment);
                }
                self::$lastPostModified = true;
                $url = MiragesPluginUtils::httpBuildUrl($part);
            }
            return $url;
        }
        $currentCDNType = self::getCdnType($part);
        if (in_array($currentCDNType, array(self::CDN_TYPE_QINIU, self::CDN_TYPE_UPYUN, self::CDN_TYPE_ALIYUN_OSS))) {
            if (array_key_exists('fragment', $part) && !empty($part['fragment'])) {
                $fragment = $part['fragment'];
                $fragment = str_replace("#", "&", $fragment);
                $fragment = MiragesPluginUtils::httpParseQuery($fragment);

                if (array_key_exists(self::KEY_WIDTH, $fragment) && array_key_exists(self::KEY_HEIGHT, $fragment)) {
                    if (intval($fragment[self::KEY_WIDTH]) > 0 && intval($fragment[self::KEY_HEIGHT]) > 0) {
                        $part['fragment'] = str_replace("#", "&", $part['fragment']);
                        return MiragesPluginUtils::httpBuildUrl($part);
                    }
                }
                if (array_key_exists('nolazyload', $fragment) || (array_key_exists('lazyload', $fragment) && $fragment['lazyload'] == 'false')) {
                    $part['fragment'] = str_replace("#", "&", $part['fragment']);
                    return MiragesPluginUtils::httpBuildUrl($part);
                }
            }

            $part4size = $part;
            unset($part4size['query']);
            unset($part4size['fragment']);
            if (!array_key_exists('scheme', $part4size)) {
                $part4size['scheme'] = 'http';
            }
            if ($currentCDNType === self::CDN_TYPE_QINIU) {
                $url4size = MiragesPluginUtils::httpBuildUrl($part4size)."?imageInfo";
            } elseif ($currentCDNType === self::CDN_TYPE_UPYUN) {
                $splitTag = self::$pluginOptions->upYunSplitTag;
                if (empty($splitTag)) {
                    $splitTag = "!";
                }
                $url4size = MiragesPluginUtils::httpBuildUrl($part4size) . $splitTag . "/info";
            } elseif ($currentCDNType === self::CDN_TYPE_ALIYUN_OSS) {
                $url4size = MiragesPluginUtils::httpBuildUrl($part4size) . "?x-oss-process=image/info";
            } else {
                $url4size = NULL;
            }
            var_dump($url4size);
            if (!empty($url4size)) {
                $json = MiragesPluginUtils::httpRequest($url4size);
            }
            if (!empty($json) && is_array($json)) {
                $width = -1;
                $height = -1;
                if (array_key_exists('width', $json) && array_key_exists('height', $json)) {
                    $width = $json['width'];
                    $height = $json['height'];
                } elseif (array_key_exists('ImageWidth', $json) && array_key_exists('ImageHeight', $json)) {
                    $_w = $json['ImageWidth'];
                    $_h = $json['ImageHeight'];
                    $width = @$_w['value'];
                    $height = @$_h['value'];
                }
                if (intval($width) > 0 && intval($height) > 0) {
                    $fragment[self::KEY_WIDTH] = intval($width);
                    $fragment[self::KEY_HEIGHT] = intval($height);
                    $fragment[self::KEY_CDN_TYPE] = $currentCDNType;
                    $part['fragment'] = http_build_query($fragment);
                    self::$lastPostModified = true;
                }
            }
        } else {

        }
        $url = MiragesPluginUtils::httpBuildUrl($part);
        return $url;
    }

    private static function getThumbnailByCdnType($url, $cdnType) {
        $part = parse_url($url);
        $cdnType = MiragesPluginUtils::trimAttributeValue($cdnType);
        if (self::CDN_TYPE_QINIU == $cdnType) {
            $part['query'] = "imageView2/2/w/64/q/20";
            unset($part['fragment']);
            return MiragesPluginUtils::httpBuildUrl($part);
        } elseif (self::CDN_TYPE_UPYUN == $cdnType) {
            $splitTag = self::$pluginOptions->upYunSplitTag;
            if (empty($splitTag)) {
                $splitTag = "!";
            }
            $part['path'] .= $splitTag . "/max/64";
            unset($part['fragment']);
            return MiragesPluginUtils::httpBuildUrl($part);
        } elseif (self::CDN_TYPE_ALIYUN_OSS == $cdnType) {
            $part['query'] = "x-oss-process=image/resize,w_64/quality,Q_20";
            unset($part['fragment']);
            return MiragesPluginUtils::httpBuildUrl($part);
        }
        return $url;
    }

    public static function UPYunSplitTag() {
        self::loadPluginOptions();
        return self::$pluginOptions->upYunSplitTag;
    }

    public static function outputGetCDNTypeJS() {
        self::loadPluginOptions();
        echo <<<EOF
var getCDNType = function() {
}
EOF;

    }

    //endregion

    //region 表情解析方法
    private static function doParseBiaoqing($content) {
        $content = preg_replace_callback('/\#\[\s*(呵呵|哈哈|吐舌|太开心|笑眼|花心|小乖|乖|捂嘴笑|滑稽|你懂的|不高兴|怒|汗|黑线|泪|真棒|喷|惊哭|阴险|鄙视|酷|啊|狂汗|what|疑问|酸爽|呀咩爹|委屈|惊讶|睡觉|笑尿|挖鼻|吐|犀利|小红脸|懒得理|勉强|爱心|心碎|玫瑰|礼物|彩虹|太阳|星星月亮|钱币|茶杯|蛋糕|大拇指|胜利|haha|OK|沙发|手纸|香蕉|便便|药丸|红领巾|蜡烛|音乐|灯泡|开心|钱|咦|呼|冷|生气|弱|吐血)\s*\]/is',
            array('Mirages_Plugin', '_parsePaopaoBiaoqingCallback'), $content);
        $content = preg_replace_callback('/\@\(\s*(呵呵|哈哈|吐舌|太开心|笑眼|花心|小乖|乖|捂嘴笑|滑稽|你懂的|不高兴|怒|汗|黑线|泪|真棒|喷|惊哭|阴险|鄙视|酷|啊|狂汗|what|疑问|酸爽|呀咩爹|委屈|惊讶|睡觉|笑尿|挖鼻|吐|犀利|小红脸|懒得理|勉强|爱心|心碎|玫瑰|礼物|彩虹|太阳|星星月亮|钱币|茶杯|蛋糕|大拇指|胜利|haha|OK|沙发|手纸|香蕉|便便|药丸|红领巾|蜡烛|音乐|灯泡|开心|钱|咦|呼|冷|生气|弱|吐血)\s*\)/is',
            array('Mirages_Plugin', '_parsePaopaoBiaoqingCallback'), $content);
        $content = preg_replace_callback('/\#\(\s*(高兴|小怒|脸红|内伤|装大款|赞一个|害羞|汗|吐血倒地|深思|不高兴|无语|亲亲|口水|尴尬|中指|想一想|哭泣|便便|献花|皱眉|傻笑|狂汗|吐|喷水|看不见|鼓掌|阴暗|长草|献黄瓜|邪恶|期待|得意|吐舌|喷血|无所谓|观察|暗地观察|肿包|中枪|大囧|呲牙|抠鼻|不说话|咽气|欢呼|锁眉|蜡烛|坐等|击掌|惊喜|喜极而泣|抽烟|不出所料|愤怒|无奈|黑线|投降|看热闹|扇耳光|小眼睛|中刀)\s*\)/is',
            array('Mirages_Plugin', '_parseAruBiaoqingCallback'), $content);

        return $content;
    }

    private static function _parsePaopaoBiaoqingCallback($match) {
        return "<img class=\"biaoqing newpaopao\" src=\"".self::$biaoqingRootPath['paopao'] . str_replace('%', '', urlencode($match[1])) . "_2x.png\" height=\"30\" width=\"30\" no-zoom>";
    }
    private static function _parseAruBiaoqingCallback($match) {
        return "<img class=\"biaoqing alu\" src=\"".self::$biaoqingRootPath['aru'] . str_replace('%', '', urlencode($match[1])) . "_2x.png\" height=\"33\" width=\"33\" no-zoom>";
    }

    public static function parseBiaoqing($content) {
        self::loadPluginOptions();
        return self::doParseBiaoqing($content);
    }
    public static function biaoqingRootPath() {
        self::loadPluginOptions();
        return self::$biaoqingRootPath;
    }
    //endregion

    //region 内容分块处理方法
    /**
     * 处理 Markdown 文本，确保不会解析代码块中的内容
     * @param $markdown
     * @param callable $callable
     * @return string
     */
    private static function handleMarkdown($markdown, $callable) {
        $replaceStartIndex = array();
        $replaceEndIndex = array();
        $currentReplaceId = 0;
        $searchIndex = 0;
        $contentLength = strlen($markdown);

        while (true) {
            $codeBlockStartIndex = false;
            $codeBlockEndIndex = false;
            $inlineCodeStartIndex = false;
            $inlineCodeEndIndex = false;
            if (preg_match('{
				(?:\n|\r|\A)
				# 1: Opening marker
				\s*(
					~{3,}|`{3,} # Marker: three tilde or more.
				)
				
				[ ]?(\w+)?(?:,[ ]?(\d+))?[ ]* (\n|\r)+ # Whitespace and newline following marker.
				
				# 3: Content
				(
					(?>
						(?!\1 [ ]* (\n|\r))	# Not a closing marker.
						.*(\n|\r)+
					)+
				)
				
				# Closing marker.
				\s*\1 [ ]* (\n|\r)+
			}xm', $markdown, $matches, 0, $searchIndex)) {
                $codeBlockStartIndex = strpos($markdown, $matches[0], $searchIndex);
                if ($codeBlockStartIndex) {
                    $codeBlockEndIndex = $codeBlockStartIndex + strlen($matches[0]);
                }
            }
            if (preg_match('/`+([^\n]*?)`+/sm', $markdown, $matches, 0, $searchIndex)) {
                $inlineCodeStartIndex = strpos($markdown, $matches[0], $searchIndex);
                if ($inlineCodeStartIndex) {
                    $inlineCodeEndIndex = $inlineCodeStartIndex + strlen($matches[0]);
                }
            }
            if (!$codeBlockStartIndex) {
                $codeBlockStartIndex = $contentLength;
            }
            if (!$inlineCodeStartIndex) {
                $inlineCodeStartIndex = $contentLength;
            }
            $useBlock = false;
            if ($codeBlockStartIndex <= $inlineCodeStartIndex) {
                $useBlock = true;
            }
            $replaceStartIndex[$currentReplaceId] = $searchIndex;
            $replaceEndIndex[$currentReplaceId] = $useBlock ? $codeBlockStartIndex : $inlineCodeStartIndex;;
            $searchIndex = $useBlock ? $codeBlockEndIndex : $inlineCodeEndIndex;
            $currentReplaceId++;
            if ($codeBlockStartIndex >= $contentLength && $inlineCodeStartIndex>= $contentLength) {
                break;
            }
        }

        $output = "";
        $output .= substr($markdown, 0, $replaceStartIndex[0]);
        for ($i = 0; $i < count($replaceStartIndex); $i++) {
            $part = substr($markdown, $replaceStartIndex[$i], $replaceEndIndex[$i] - $replaceStartIndex[$i]);
            $renderedPart = self::handleHtml($part, $callable);
            $output.= $renderedPart;

            if ($i < count($replaceStartIndex) - 1) {
                $output.= substr($markdown, $replaceEndIndex[$i], $replaceStartIndex[$i + 1] - $replaceEndIndex[$i]);
            }
        }
        $output .= substr($markdown, $replaceEndIndex[count($replaceStartIndex) - 1]);
        return $output;
    }

    /**
     * 处理 HTML 文本，确保不会解析代码块中的内容
     * @param $content
     * @param callable $callback
     * @return string
     */
    private static function handleHtml($content, $callback) {
        $replaceStartIndex = array();
        $replaceEndIndex = array();
        $currentReplaceId = 0;
        $replaceIndex = 0;
        $searchIndex = 0;
        $searchCloseTag = false;
        $contentLength = strlen($content);
        while (true) {
            if ($searchCloseTag) {
                $tagName = substr($content, $searchIndex, 4);
                if ($tagName == "<cod") {
                    $searchIndex = strpos($content, '</code>', $searchIndex);
                    if (!$searchIndex) {
                        break;
                    }
                    $searchIndex += 7;
                } elseif ($tagName == "<pre") {
                    $searchIndex = strpos($content, '</pre>', $searchIndex);
                    if (!$searchIndex) {
                        break;
                    }
                    $searchIndex += 6;
                } elseif ($tagName == "<kbd") {
                    $searchIndex = strpos($content, '</kbd>', $searchIndex);
                    if (!$searchIndex) {
                        break;
                    }
                    $searchIndex += 6;
                } elseif ($tagName == "<scr") {
                    $searchIndex = strpos($content, '</script>', $searchIndex);
                    if (!$searchIndex) {
                        break;
                    }
                    $searchIndex += 9;
                } elseif ($tagName == "<sty") {
                    $searchIndex = strpos($content, '</style>', $searchIndex);
                    if (!$searchIndex) {
                        break;
                    }
                    $searchIndex += 8;
                } else {
                    break;
                }

                if (!$searchIndex) {
                    break;
                }
                $replaceIndex = $searchIndex;
                $searchCloseTag = false;
                continue;
            } else {
                $searchCodeIndex = strpos($content, '<code', $searchIndex);
                $searchPreIndex = strpos($content, '<pre', $searchIndex);
                $searchKbdIndex = strpos($content, '<kbd', $searchIndex);
                $searchScriptIndex = strpos($content, '<script', $searchIndex);
                $searchStyleIndex = strpos($content, '<style', $searchIndex);
                if (!$searchCodeIndex) {
                    $searchCodeIndex = $contentLength;
                }
                if (!$searchPreIndex) {
                    $searchPreIndex = $contentLength;
                }
                if (!$searchKbdIndex) {
                    $searchKbdIndex = $contentLength;
                }
                if (!$searchScriptIndex) {
                    $searchScriptIndex = $contentLength;
                }
                if (!$searchStyleIndex) {
                    $searchStyleIndex = $contentLength;
                }
                $searchIndex = min($searchCodeIndex, $searchPreIndex, $searchKbdIndex, $searchScriptIndex, $searchStyleIndex);
                $searchCloseTag = true;
            }
            $replaceStartIndex[$currentReplaceId] = $replaceIndex;
            $replaceEndIndex[$currentReplaceId] = $searchIndex;
            $currentReplaceId++;
            $replaceIndex = $searchIndex;
        }

        $output = "";
        $output .= substr($content, 0, $replaceStartIndex[0]);
        for ($i = 0; $i < count($replaceStartIndex); $i++) {
            $part = substr($content, $replaceStartIndex[$i], $replaceEndIndex[$i] - $replaceStartIndex[$i]);
            if (is_array($callback)) {
                $className = $callback[0];
                $method = $callback[1];
                $renderedPart = call_user_func($className.'::'.$method, $part);
            } else {
                $renderedPart = $callback($part);
            }
            $output.= $renderedPart;
            if ($i < count($replaceStartIndex) - 1) {
                $output.= substr($content, $replaceEndIndex[$i], $replaceStartIndex[$i + 1] - $replaceEndIndex[$i]);
            }
        }
        $output .= substr($content, $replaceEndIndex[count($replaceStartIndex) - 1]);
        return $output;
    }
    //endregion

    //region Options 及其相关信息
    private static function loadPluginOptions() {
        if (self::$optionLoaded) {
            return;
        }
        self::$themeOptions = Typecho_Widget::widget('Widget_Options');
        self::$pluginOptions = self::$themeOptions->plugin("Mirages");
        self::$pluginBaseUrl = rtrim(preg_replace('/^'.preg_quote(rtrim(self::$themeOptions->siteUrl, '/'), '/').'/', rtrim(self::$themeOptions->rootUrl, '/'), self::$themeOptions->pluginUrl, 1),'/').'/Mirages/';

        // 七牛自定义域名
        $customQiniuHosts = self::$pluginOptions->customQiniuHosts;
        if (!empty($customQiniuHosts)) {
            $customQiniuHosts = mb_split("(\n|\r)", $customQiniuHosts);
            self::$cdnHosts[self::CDN_NAME_QINIU] = array_merge(self::$cdnHosts[self::CDN_NAME_QINIU], $customQiniuHosts);
            self::$cdnHosts[self::CDN_NAME_QINIU] = array_unique(self::$cdnHosts[self::CDN_NAME_QINIU]);
        }

        // 又拍云自定义域名
        $customUPYunHosts = self::$pluginOptions->customUPYunHosts;
        if (!empty($customUPYunHosts)) {
            $customUPYunHosts = mb_split("(\n|\r)", $customUPYunHosts);
            self::$cdnHosts[self::CDN_NAME_UPYUN] = array_merge(self::$cdnHosts[self::CDN_NAME_UPYUN], $customUPYunHosts);
            self::$cdnHosts[self::CDN_NAME_UPYUN] = array_unique(self::$cdnHosts[self::CDN_NAME_UPYUN]);
        }

        $customCDNHosts = self::$pluginOptions->customCDNHosts;
        if (!empty($customCDNHosts)) {
            $customHosts = mb_split("(\n|\r)", $customCDNHosts);
            foreach ($customHosts as $customHost) {
                $type = mb_split(":", $customHost, 2);
                if (is_array($type) && count($type) == 2) {
                    $host = trim($type[0]);
                    $cdn = strtoupper(trim($type[1]));
                    if (!array_key_exists($cdn, self::$cdnHosts)) {
                        self::$cdnHosts[$cdn] = array();
                    }
                    self::$cdnHosts[$cdn][] = $host;
                }
            }

            foreach (array_keys(self::$cdnHosts) as $key) {
                self::$cdnHosts[$key] = array_unique(self::$cdnHosts[$key]);
            }
        }

        //表情自定义路径
        $biaoqingRootPath = self::$pluginOptions->biaoqingRootPath;
        if (!empty($biaoqingRootPath)) {
            $biaoqingRootPath = mb_split("(\n|\r)", $biaoqingRootPath);
            foreach ($biaoqingRootPath as $path) {
                $item = mb_split(":", $path, 2);
                if (count($item) !== 2) continue;

                $biaoqingName = strtolower(trim($item[0]));
                $biaoqingPath = trim($item[1]);
                $biaoqingPath = rtrim($biaoqingPath, '/').'/';

                self::$biaoqingRootPath[$biaoqingName] = $biaoqingPath;
            }
        }
        $embedBiaoqingRootPath = rtrim(self::$pluginBaseUrl, '/').'/biaoqing/';
        if (!array_key_exists('paopao', self::$biaoqingRootPath)) {
            self::$biaoqingRootPath['paopao'] = $embedBiaoqingRootPath . 'paopao/';
        }
        if (!array_key_exists('aru', self::$biaoqingRootPath)) {
            self::$biaoqingRootPath['aru'] = $embedBiaoqingRootPath . 'aru/';
        }

        self::$optionLoaded = true;
    }

    private static function loadThemeVersion() {
        $themeName = Helper::options()->theme;
        if (!empty($themeName)) {
            $file = Helper::options()->themeFile($themeName, '/lib/Mirages.php');
            if (file_exists($file)) {
                if (!class_exists("Mirages")) {
                    require_once($file);
                }
                if (strlen(Mirages::$version) > 5) {
                    $themeVersion = substr(Mirages::$version, 0, 5);
                } else {
                    $themeVersion = Mirages::$version;
                }
                $themeVersion = preg_replace('/\D/i', '', $themeVersion);
                self::$themeVersion = intval($themeVersion);
            }
        }
    }

    private static function lazyloadEnabled() {
        if (self::$themeVersion < 0) {
            self::loadThemeVersion();
        }

        return (self::$themeVersion >= self::VERSION_REQUIRED_LAZYLOAD && self::$themeOptions->enableLazyLoad == 1);
    }
    //endregion

}

class Title_Plugin extends Typecho_Widget_Helper_Form_Element
{

    public function label($value)
    {
        /** 创建标题元素 */
        if (empty($this->label)) {
            $this->label = new Typecho_Widget_Helper_Layout('label', array('class' => 'typecho-label', 'style'=>'font-size: 2em;border-bottom: 1px #ddd solid;padding-top:2em;'));
            $this->container($this->label);
        }

        $this->label->html($value);
        return $this;
    }

    public function input($name = NULL, array $options = NULL)
    {
        $input = new Typecho_Widget_Helper_Layout('p', array());
        $this->container($input);
        $this->inputs[] = $input;
        return $input;
    }

    protected function _value($value) {}

}