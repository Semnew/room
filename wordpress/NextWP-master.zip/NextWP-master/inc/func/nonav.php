<?php
function noNav(){
    echo '<div style="height: 30px;width:30%;line-height:60px;color:#000;float: right;text-align: center">请到后台添加菜单</div>';

}
?>