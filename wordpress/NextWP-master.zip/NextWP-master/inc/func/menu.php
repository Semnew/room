<?php
//注册菜单
register_nav_menus(array(
    'main-menu' => '主菜单',


));




?>